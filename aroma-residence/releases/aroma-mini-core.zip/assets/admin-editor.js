'use strict';
/** Additive SEO and image upload tools; original admin editor markup remains unchanged. */
(() => {
  const form = document.getElementById('product-form');
  const table = document.getElementById('product-list');
  const status = document.getElementById('notice');
  if (!form || !table || document.getElementById('ar-extra-editor')) return;
  const fieldset = form.querySelector('fieldset');
  if (!fieldset) return;
  const extra = document.createElement('div'); extra.id = 'ar-extra-editor';extra.className='ar-editor-extra a-wide';
  const header = document.createElement('h3');header.textContent='Фото и SEO';extra.append(header);
  const hint = document.createElement('p');hint.className='ar-editor-hint';
  hint.textContent='URL товара формируется из ID (латиница и дефисы). SEO-поля применяются после сохранения и обновления страницы.';
  extra.append(hint);
  const fields = [
    {name:'title',title:'Название аромата (короткое)',max:160},
    {name:'seoTitle',title:'SEO Title',max:120},
    {name:'seoH1',title:'H1 — заголовок карточки',max:160},
    {name:'seoDescription',title:'SEO Description',max:240,area:true},
    {name:'seoKeywords',title:'SEO Keywords',max:500,area:true},
  ];
  for (const def of fields) {
    const lbl=document.createElement('label');lbl.className='ar-editor-field';lbl.textContent=def.title;
    const input=document.createElement(def.area?'textarea':'input');input.name=def.name;input.maxLength=def.max;
    if (def.area)input.rows=3;input.autocomplete='off';lbl.append(input);extra.append(lbl);
  }
  const imageLabel=document.createElement('label');imageLabel.className='ar-editor-field';imageLabel.textContent='Загрузить фотографию (JPEG, PNG, WebP)';
  const fileInput=document.createElement('input');fileInput.type='file';fileInput.accept='image/jpeg,image/png,image/webp';fileInput.className='ar-editor-file';
  const note=document.createElement('span');note.className='ar-editor-upload-note';note.textContent='Выберите изображение — оно будет преобразовано в WebP и сохранено на сервере в РФ.';
  imageLabel.append(fileInput,note);extra.append(imageLabel);
  const submit=form.querySelector('button[type="submit"]');
  if(submit?.parentNode?.parentNode===fieldset)fieldset.insertBefore(extra,submit.parentNode);else fieldset.append(extra);
  let products=new Map();
  const setNotice=(value,bad=false)=>{if(status){status.textContent=value;status.style.color=bad?'#9b3737':'#24604c';}};
  const api=async(action,method='GET',payload,contentType='application/json')=>{
    const response=await fetch('/api/admin?action='+encodeURIComponent(action),{
      method,credentials:'same-origin',cache:'no-store',
      headers:{'x-aroma-admin':'1','content-type':contentType},
      body:payload?(contentType==='application/json'?JSON.stringify(payload):payload):undefined,
    });
    const json=await response.json().catch(()=>({}));
    if(!response.ok)throw Error(json.error||'Ошибка сервера');return json;
  };
  const refreshProducts=async()=>{
    const data=await api('dashboard');products=new Map((data.products||[]).map(p=>[p.id,p]));
  };
  const setExtras=product=>{
    for(const def of fields){const input=form.elements.namedItem(def.name);if(input)input.value=product?.[def.name]||'';}
  };
  table.addEventListener('click',(event)=>{
    const button=event.target?.closest?.('button');if(!button)return;
    queueMicrotask(()=>{
      const id=form.elements.namedItem('id')?.value;
      setExtras(products.get(id));
    });
  },true);
  const newButton=document.getElementById('new-product');
  newButton?.addEventListener('click',()=>queueMicrotask(()=>setExtras(null)),true);
  const dash=document.getElementById('dash');
  if(dash){const observer=new MutationObserver(()=>{if(!dash.hidden)refreshProducts().catch(()=>{})});observer.observe(dash,{attributes:true,attributeFilter:['hidden']});if(!dash.hidden)refreshProducts().catch(()=>{});}
  fileInput.addEventListener('change',async()=>{
    const file=fileInput.files?.[0];if(!file)return;
    if(file.size>8_000_000){setNotice('Фото должно быть меньше 8 МБ.',true);fileInput.value='';return;}
    if(!['image/png','image/webp','image/jpeg'].includes(file.type)){setNotice('Поддерживается JPEG, PNG или WebP.',true);fileInput.value='';return;}
    fileInput.disabled=true;note.textContent='Обрабатываем фотографию…';
    try{
      const bitmap=await createImageBitmap(file);
      const scale=Math.min(1,1400/Math.max(bitmap.width,bitmap.height));
      const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);
      if(canvas.width<1||canvas.height<1)throw Error('Фотография повреждена.');
      const ctx=canvas.getContext('2d');if(!ctx)throw Error('Ваш браузер не поддерживает обработку фото.');
      ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close?.();
      const data=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',.82));
      if(!data||data.size>2_097_152)throw Error('Фото слишком большое. Попробуйте другое изображение.');
      const result=await api('upload','POST',data,'image/webp');
      if(!/^\/media\/[0-9a-f-]{36}\.webp$/.test(result.url||''))throw Error('Сервер не подтвердил загрузку.');
      const image=form.elements.namedItem('image');if(image)image.value=result.url;
      note.textContent='Фото загружено. Сохраните товар, чтобы закрепить фотографию.';
    }catch(e){setNotice(e.message||'Не удалось загрузить фото.',true);note.textContent='Повторите загрузку или выберите другой файл.';}
    finally{fileInput.disabled=false;fileInput.value='';}
  });
  form.addEventListener('submit',async event=>{
    // Capture before legacy form handler. This extends the payload instead of sending conflicting duplicate writes.
    event.preventDefault();event.stopImmediatePropagation();
    if(!form.reportValidity())return;
    const data=new FormData(form);
    const value=name=>String(data.get(name)||'').trim();
    const product={id:value('id'),name:value('name'),brand:value('brand'),description:value('description'),image:value('image'),prices:{}};
    for(const def of fields)product[def.name]=value(def.name);
    for(const ml of [2,3,5,10,15]){
      const v=value('p'+ml);if(v!==''&&!Number.isNaN(Number(v)))product.prices[ml]=Number(v);
    }
    const btn=form.querySelector('button[type="submit"]');if(btn)btn.disabled=true;
    try{await api('product','PUT',product);setNotice('Товар сохранён. Обновляем каталог…');window.location.reload();}
    catch(e){setNotice(e.message||'Не удалось сохранить товар.',true)}
    finally{if(btn)btn.disabled=false;}
  },true);
})();
