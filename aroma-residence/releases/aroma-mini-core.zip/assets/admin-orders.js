'use strict';
/** Isolated enhancement for the existing Aroma Residence admin. */
(() => {
  const dash = document.getElementById('dash');
  if (!dash || document.getElementById('ar-new-orders-panel')) return;
  const el = (tag, cls, value) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (value !== undefined) e.textContent = String(value);
    return e;
  };
  const panel = el('section', 'ar-orders-panel');
  panel.id = 'ar-new-orders-panel';
  panel.setAttribute('aria-labelledby', 'ar-new-orders-title');
  const top = el('div', 'ar-orders-heading');
  const head = el('div');
  const eyebrow = el('span', 'ar-orders-eyebrow', 'PRIVATE ATELIER · ORDERS');
  const title = el('h2', '', 'Новые заказы');
  title.id = 'ar-new-orders-title';
  const count = el('span', 'ar-orders-count', '—');
  head.append(eyebrow, title, count);
  const refresh = el('button', 'ar-orders-refresh', 'Обновить');
  refresh.type = 'button';
  top.append(head, refresh);
  const status = el('p', 'ar-orders-state', 'Для просмотра заказов войдите в админку.');
  status.setAttribute('role', 'status');
  const rows = el('div', 'ar-orders-list');
  panel.append(top, status, rows);
  const oldTable = document.getElementById('orders');
  const anchor = oldTable?.closest('.a-scroll')?.previousElementSibling;
  if (anchor?.parentElement === dash) dash.insertBefore(panel, anchor);
  else dash.prepend(panel);
  const statuses = Object.freeze({new: 'Новый', processing: 'В работе', completed: 'Завершён', cancelled: 'Отменён'});
  const money = n => new Intl.NumberFormat('ru-RU').format(Number(n || 0)) + ' ₽';
  let busy = false;
  let last = [];
  const api = async (action, method='GET', payload) => {
    const response = await fetch('/api/admin?action=' + encodeURIComponent(action), {
      method, credentials: 'same-origin', cache: 'no-store',
      headers: {'x-aroma-admin': '1', 'content-type': 'application/json'},
      body: payload ? JSON.stringify(payload) : undefined,
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || `Сервер вернул HTTP ${response.status}`);
    return body;
  };
  const buildRow = order => {
    const card = el('article', 'ar-order-card');
    const meta = el('div', 'ar-order-meta');
    const orderId = el('strong', '', order.orderId || 'Заказ');
    const date = el('time', '', new Date(order.createdAt).toLocaleString('ru-RU'));
    const customer = el('p', 'ar-order-customer', String(order.name || '') + ' · ' + String(order.phone || ''));
    const amount = el('span', 'ar-order-amount', money(order.total));
    meta.append(orderId, date, customer, amount);
    if (order.email) meta.append(el('p', 'ar-order-contact', 'Email: ' + order.email));
    const items = el('ul', 'ar-order-items');
    for (const item of (Array.isArray(order.items) ? order.items : [])) {
      items.append(el('li', '', `${item.name || item.id} · ${item.ml} мл × ${item.qty}`));
    }
    const shipping = el('p', 'ar-order-shipping', 'Получение: ' + (order.delivery || 'Не указано'));
    if (order.address && typeof order.address === 'object') {
      const addr = Object.values(order.address).filter(x => typeof x === 'string' && x.trim()).join(', ');
      if (addr) shipping.append(' · ' + addr);
    }
    if (order.comment) shipping.append(' · Комментарий: ' + String(order.comment));
    const actions = el('div', 'ar-order-actions');
    const lbl = el('label', '', 'Статус');
    const select = el('select');
    for (const [value,label] of Object.entries(statuses)) {
      const opt = el('option', '', label);opt.value = value;select.append(opt);
    }
    select.value = Object.hasOwn(statuses, order.status) ? order.status : 'new';
    lbl.append(select);
    const save = el('button', 'ar-orders-save', 'Сохранить статус');save.type = 'button';
    save.addEventListener('click', async () => {
      if (save.disabled || order.status === select.value) return;
      save.disabled = true;
      try { await api('order', 'PATCH', {id: order.id, status: select.value});
        status.textContent = `Статус заказа ${order.orderId || ''} сохранён.`;await load();
      } catch (e) { status.textContent = e.message || 'Не удалось изменить статус.'; }
      finally { save.disabled = false; }
    });
    actions.append(lbl, save);
    card.append(meta, items, shipping, actions);
    return card;
  };
  const render = () => {
    const newOrders = last.filter(o => o.status === 'new');
    count.textContent = `${newOrders.length} новых`;
    if (newOrders.length === 0) {
      rows.replaceChildren(el('div', 'ar-orders-empty', 'Новых заказов пока нет.'));
    } else rows.replaceChildren(...newOrders.map(buildRow));
  };
  async function load() {
    if (busy || dash.hidden || document.hidden) return;
    busy = true;refresh.disabled = true;
    status.textContent = 'Обновляем список заказов…';
    try {
      const response = await api('orders');
      if (!Array.isArray(response.orders)) throw new Error('Неверный формат ответа от сервера.');
      last = response.orders;render();
      status.textContent = 'Список обновлён. Всего заказов: ' + last.length + '.';
    } catch (e) { status.textContent = e.message || 'Не удалось загрузить заказы.'; }
    finally { busy = false;refresh.disabled = false; }
  }
  refresh.addEventListener('click', load);
  const observer = new MutationObserver(() => {if (!dash.hidden) load();});
  observer.observe(dash, {attributes:true, attributeFilter:['hidden']});
  document.addEventListener('visibilitychange', () => {if (!document.hidden) load();});
  window.setInterval(() => {if (!document.hidden && !dash.hidden) load();}, 30_000);
  if (!dash.hidden) load();
})();
