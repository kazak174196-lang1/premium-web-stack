'use strict';
(() => {
  document.querySelectorAll('[data-product-page]').forEach(root => {
    const buttons = Array.from(root.querySelectorAll('[data-page-size]'));
    buttons.forEach(button => button.addEventListener('click', () => {
      for(const peer of buttons){const active=peer===button;peer.classList.toggle('active',active);peer.setAttribute('aria-pressed',String(active));}
    }));
  });
})();
