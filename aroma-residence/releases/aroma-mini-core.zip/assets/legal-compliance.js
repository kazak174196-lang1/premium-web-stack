'use strict';
(() => {
  const KEY = 'aroma-cookie-preferences-v1';
  const VERSION = '2026-11-16';
  const categories = Object.freeze({
    analytics: false,
    marketing: false,
  });
  const active = Object.freeze({
    analytics: document.documentElement.dataset.arAnalyticsEnabled === 'true',
    marketing: document.documentElement.dataset.arMarketingEnabled === 'true',
  });
  let previousFocus = null;
  let banner = null;
  let dialog = null;

  const getSaved = () => {
    try {
      const parsed = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (!parsed || parsed.version !== VERSION || typeof parsed.updatedAt !== 'string') return null;
      if (!parsed.choices || typeof parsed.choices !== 'object') return null;
      return {
        analytics: active.analytics && parsed.choices.analytics === true,
        marketing: active.marketing && parsed.choices.marketing === true,
      };
    } catch { return null; }
  };

  const sendChange = (choices) => {
    const detail = Object.freeze({
      version: VERSION,
      necessary: true,
      analytics: active.analytics && choices.analytics === true,
      marketing: active.marketing && choices.marketing === true,
    });
    document.dispatchEvent(new CustomEvent('aroma:privacy-choices', {detail}));
  };

  const save = (choices) => {
    const allowed = {
      analytics: active.analytics && choices.analytics === true,
      marketing: active.marketing && choices.marketing === true,
    };
    try {
      localStorage.setItem(KEY, JSON.stringify({
        version: VERSION,
        choices: allowed,
        updatedAt: new Date().toISOString(),
      }));
    } catch {
      // Private browsing and disabled storage must not prevent site use.
    }
    sendChange(allowed);
    if (banner) banner.hidden = true;
    closeDialog();
  };

  const node = (tag, className, textValue) => {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (typeof textValue === 'string') result.textContent = textValue;
    return result;
  };
  const link = (url, caption) => {
    const anchor = node('a', 'ar-legal-link', caption);
    anchor.href = url;
    return anchor;
  };
  const button = (label, className, callback) => {
    const element = node('button', className, label);
    element.type = 'button';
    element.addEventListener('click', callback);
    return element;
  };

  const closeDialog = () => {
    if (!dialog) return;
    dialog.remove();
    dialog = null;
    document.removeEventListener('keydown', trapFocus);
    const focus = previousFocus;
    previousFocus = null;
    if (focus?.isConnected) focus.focus();
  };
  const trapFocus = (event) => {
    if (!dialog) return;
    if (event.key === 'Escape') {
      closeDialog();
      return;
    }
    if (event.key !== 'Tab') return;
    const elements = Array.from(dialog.querySelectorAll('button:not([disabled]),input:not([disabled]),a[href]'));
    if (!elements.length) return;
    const first = elements[0];
    const last = elements[elements.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      last.focus();
      event.preventDefault();
    } else if (!event.shiftKey && document.activeElement === last) {
      first.focus();
      event.preventDefault();
    }
  };

  const openDialog = () => {
    if (dialog) return;
    previousFocus = document.activeElement;
    const backdrop = node('div', 'ar-legal-overlay');
    const panel = node('section', 'ar-legal-dialog');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-labelledby', 'ar-privacy-dialog-title');
    const header = node('div', 'ar-legal-dialog-top');
    const title = node('h2', '', 'Настройки конфиденциальности');
    title.id = 'ar-privacy-dialog-title';
    header.append(title, button('Закрыть', 'ar-legal-close', closeDialog));
    panel.append(header, node('p', 'ar-legal-dialog-lede', 'Вы управляете необязательными технологиями. Корзина и базовые функции сайта работают без разрешения на аналитику.'));
    const necessary = node('div', 'ar-legal-option');
    const necessaryText = node('div');
    necessaryText.append(node('strong', '', 'Необходимые'), node('p', '', 'Корзина, выбранные настройки и защита форм. Всегда активны.'));
    necessary.append(necessaryText, node('span', 'ar-legal-required', 'Всегда включены'));
    panel.append(necessary);
    const saved = getSaved() || categories;
    const checks = {};
    for (const [name, desc] of [
      ['analytics', ['Аналитика', 'Помогает изучать посещаемость после подключения конкретного сервиса.']],
      ['marketing', ['Маркетинговые', 'Используются для персонализированной рекламы после подключения конкретного сервиса.']],
    ]) {
      if (!active[name]) continue;
      const line = node('label', 'ar-legal-option');
      const left = node('div');
      left.append(node('strong', '', desc[0]), node('p', '', desc[1]));
      const checkbox = node('input');
      checkbox.type = 'checkbox';
      checkbox.checked = saved[name];
      checks[name] = checkbox;
      line.append(left, checkbox);
      panel.append(line);
    }
    const information = node('p', 'ar-legal-dialog-note');
    information.append('Подробнее: ', link('/cookies/', 'Политика cookies'), ' · ', link('/privacy/', 'Персональные данные'));
    const actions = node('div', 'ar-legal-actions');
    actions.append(button('Только необходимые', 'ar-legal-button ar-legal-button-outline', () => save(categories)));
    const optionalEnabled = active.analytics || active.marketing;
    if (optionalEnabled) {
      actions.append(button('Сохранить выбор', 'ar-legal-button ar-legal-button-primary', () => save({
        analytics: checks.analytics?.checked === true,
        marketing: checks.marketing?.checked === true,
      })));
    } else {
      actions.append(button('Понятно', 'ar-legal-button ar-legal-button-primary', () => save(categories)));
    }
    panel.append(information, actions);
    backdrop.append(panel);
    backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeDialog(); });
    document.body.append(backdrop);
    dialog = backdrop;
    document.addEventListener('keydown', trapFocus);
    panel.querySelector('button')?.focus();
  };

  const buildBanner = () => {
    banner = node('aside', 'ar-legal-cookie-banner');
    banner.setAttribute('aria-label', 'Информация о cookies');
    const text = node('div', 'ar-legal-cookie-copy');
    text.append(node('strong', '', 'Ваш выбор. Ваши данные.'));
    const description = node('p');
    description.append('Мы используем необходимые данные браузера для работы корзины. Необязательные технологии запускаются только с вашего разрешения. ', link('/cookies/', 'Подробнее о cookies'));
    text.append(description);
    const actions = node('div', 'ar-legal-cookie-actions');
    actions.append(button('Настроить', 'ar-legal-button ar-legal-button-outline', openDialog));
    actions.append(button('Только необходимые', 'ar-legal-button ar-legal-button-primary', () => save(categories)));
    banner.append(text, actions);
    document.body.append(banner);
  };

  const prepareMaps = () => {
    document.querySelectorAll('iframe[data-ar-map-optin=\"1\"][data-ar-map-src]').forEach((iframe) => {
      const raw = iframe.getAttribute('data-ar-map-src') || '';
      let url;
      try { url = new URL(raw, document.baseURI); } catch { return; }
      if (url.protocol !== 'https:' || url.hostname !== 'yandex.ru' || !url.pathname.startsWith('/map-widget/')) return;
      const parent = iframe.parentElement;
      if (!parent || parent.querySelector('.ar-legal-map-optin')) return;
      parent.classList.add('ar-legal-map-container');
      const overlay = node('div', 'ar-legal-map-optin');
      const body = node('div', 'ar-legal-map-details');
      body.append(node('span', 'ar-legal-map-overline', 'ЧЕЛЯБИНСК · КАК НАС НАЙТИ'));
      body.append(node('strong', '', 'Магазин на карте'));
      body.append(node('p', '', 'Карта загружается с сервиса Яндекса и передаёт ему технические данные браузера. Открыть карту?'));
      const open = button('Загрузить карту', 'ar-legal-button ar-legal-button-primary', () => {
        iframe.src = url.href;
        iframe.style.visibility = '';
        iframe.removeAttribute('data-ar-map-src');
        overlay.remove();
      });
      body.append(open);
      overlay.append(body);
      iframe.style.visibility = 'hidden';
      parent.append(overlay);
    });
  };

  const init = () => {
    prepareMaps();
    document.querySelectorAll('[data-ar-privacy-settings]').forEach((trigger) => {
      trigger.addEventListener('click', (event) => {event.preventDefault(); openDialog();});
    });
    const saved = getSaved();
    if (saved) sendChange(saved);
    else buildBanner();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
  else init();
})();
