<?php
declare(strict_types=1);
/**
 * COPY to ~/.aroma_private/config.php outside public_html, then edit in Timeweb File Manager.
 * DO NOT COMMIT the filled config.php or share it in screenshots.
 * All payment/data processing gates default to false; no live customer collection yet.
 */
return [
    'siteOrigin' => 'https://aromaresidence.ru',
    'database' => [
        'dsn' => 'mysql:host=localhost;port=3306;dbname=aroma;charset=utf8mb4',
        'username' => 'REPLACE_WITH_MYSQL_USER',
        'password' => 'REPLACE_WITH_RANDOM_MYSQL_PASSWORD',
    ],
    'adminPasswordHash' => '', // Generate using php -r 'echo password_hash(readline(),PASSWORD_ARGON2ID);'
    'sessionHmacSecret' => '', // Generate via bin2hex(random_bytes(32)), locally.
    'ordersEnabled' => false,
    'rknConfirmed' => false,
    'russianStorageConfirmed' => false,
    'markingConfirmed' => false,
    'fiscalizationConfirmed' => false,
    'consentVersion' => '2026-11-16',
];
