<?php
declare(strict_types=1);

namespace Aroma\Commerce;

use InvalidArgumentException;

final class InvalidOrder extends InvalidArgumentException {}

function safeString(mixed $value, int $maxBytes, string $name, bool $required=false): string {
    if (!is_string($value)) {
        if ($value===null && !$required) return '';
        throw new InvalidOrder("Проверьте поле: {$name}.");
    }
    $value=trim($value);
    if (strlen($value)>$maxBytes || !preg_match('//u',$value) || ($required && strlen($value)===0)) {
        throw new InvalidOrder("Проверьте поле: {$name}.");
    }
    return $value;
}
/** @return array<string, array<string,mixed>> */
function catalogMap(array $products): array {
    if (!$products || count($products)>10000) throw new InvalidOrder('Каталог временно недоступен.');
    $map=[];
    foreach ($products as $p) {
        if (!is_array($p) || !isset($p['id']) || !is_string($p['id']) || !preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D',$p['id']) || !isset($p['prices']) || !is_array($p['prices']) || !isset($p['name']) || !is_string($p['name']) || isset($map[$p['id']])) {
            throw new InvalidOrder('Ошибка данных каталога.');
        }
        $map[$p['id']]=$p;
    }
    return $map;
}
/**
 * Calculates server-authoritative prices and set discounts; never trusts browser totals.
 * @param array<string,mixed> $raw
 * @param array<string,array<string,mixed>> $catalog
 * @return array<string,mixed>
 */
function priceOrder(array $raw, array $catalog): array {
    $name=safeString($raw['name']??null,200,'имя',true);
    if (strlen($name)<2) throw new InvalidOrder('Укажите имя для заказа.');
    $phone=safeString($raw['phone']??null,32,'телефон',true);
    $digits=preg_replace('/\D/','',$phone);
    if (!preg_match('/^\+?[0-9\s()\-]{10,32}$/D',$phone) || strlen($digits)<10 || strlen($digits)>15) throw new InvalidOrder('Проверьте номер телефона.');
    $email=safeString($raw['email']??null,254,'email');
    if ($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new InvalidOrder('Проверьте электронную почту.');
    if (($raw['consent']??null)!==true) throw new InvalidOrder('Подтвердите согласие на обработку данных.');
    $delivery=safeString($raw['delivery']??null,100,'доставка',true);
    $comment=safeString($raw['comment']??null,2000,'комментарий');
    $address=null;
    if (isset($raw['address'])) {
        if (!is_array($raw['address']) || array_is_list($raw['address'])) throw new InvalidOrder('Некорректный адрес.');
        $address=[];
        foreach (['type','carrier','carrierLabel','service','city','region','postalCode','street','house','apartment','pickupPoint'] as $key) {
            if (array_key_exists($key,$raw['address'])) {
                $address[$key]=safeString($raw['address'][$key],220,"адрес.{$key}");
            }
        }
    }
    $rawItems=$raw['items']??null;
    if (!is_array($rawItems) || count($rawItems)<1 || count($rawItems)>80 || !array_is_list($rawItems)) throw new InvalidOrder('Корзина пустая или содержит слишком много позиций.');
    $seen=[];$items=[];$groups=[];$subtotal=0;
    foreach ($rawItems as $entry) {
        if (!is_array($entry) || array_is_list($entry)) throw new InvalidOrder('Некорректная позиция корзины.');
        $id=$entry['id']??null;
        if (!is_string($id) || !preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D',$id)) throw new InvalidOrder('Некорректный идентификатор товара.');
        $ml=$entry['ml']??null;
        if (!is_int($ml) && !is_string($ml)) throw new InvalidOrder('Недопустимый объём товара.');
        $ml=(string)$ml;
        if (!preg_match('/^[1-9][0-9]?$/D',$ml)) throw new InvalidOrder('Недопустимый объём товара.');
        $qty=$entry['qty']??null;
        if (!is_int($qty) || $qty<1 || $qty>30) throw new InvalidOrder('Недопустимое количество товара.');
        $product=$catalog[$id]??null;
        $unit=$product['prices'][$ml]??null;
        if (!is_int($unit) && !(is_float($unit) && floor($unit)===$unit)) throw new InvalidOrder('Товар или объём отсутствует в каталоге.');
        $unit=(int)$unit;
        if ($unit<1 || $unit>1000000) throw new InvalidOrder('Товар или объём отсутствует в каталоге.');
        $setId=$entry['setId']??'';
        if ($setId===null) $setId='';
        if (!is_string($setId) || ($setId!=='' && !preg_match('/^[A-Za-z0-9-]{8,64}$/D',$setId))) throw new InvalidOrder('Неверный идентификатор сета.');
        if ($setId!=='' && $qty!==1) throw new InvalidOrder('В сете должно быть по одному флакону каждого аромата.');
        $lineKey="{$id}:{$ml}:{$setId}";
        if (isset($seen[$lineKey])) throw new InvalidOrder('Повторяющаяся позиция в корзине.');
        $seen[$lineKey]=true;
        $amount=$unit*$qty;$subtotal+=$amount;
        if ($subtotal>50000000) throw new InvalidOrder('Сумма заказа слишком велика.');
        $item=['id'=>$id,'name'=>$product['name'],'ml'=>$ml,'qty'=>$qty,'setId'=>$setId?:null,'unitPrice'=>$unit,'lineTotal'=>$amount];
        $items[]=$item;
        if ($setId!=='') $groups[$setId][]=$item;
    }
    $setDiscount=0;
    foreach ($groups as $group) {
        $n=count($group);
        if (!in_array($n,[3,5],true) || count(array_unique(array_column($group,'id')))!==$n) throw new InvalidOrder('Сет собран некорректно.');
        $sum=array_sum(array_column($group,'lineTotal'));
        $setDiscount+=(int)round($sum*($n===3?0.05:0.10),0,PHP_ROUND_HALF_UP);
    }
    $promo=safeString($raw['promoCode']??'',60,'промокод');$promo=strtoupper($promo);
    if ($promo!=='' && !preg_match('/^[A-Z0-9_-]{3,32}$/D',$promo)) throw new InvalidOrder('Некорректный промокод.');
    $identity=['phone'=>$digits,'delivery'=>$delivery,'address'=>$address,'items'=>array_map(static fn(array $x)=>[$x['id'],$x['ml'],$x['qty'],$x['setId']],$items)];
    return ['name'=>$name,'phone'=>$phone,'email'=>strtolower($email),'comment'=>$comment,'delivery'=>$delivery,'address'=>$address,'items'=>$items,'subtotal'=>$subtotal,'setDiscount'=>$setDiscount,'promoCode'=>$promo,'total'=>$subtotal-$setDiscount,'identity'=>$identity];
}
