<?php
declare(strict_types=1);
namespace Aroma\ProductPage;

use InvalidArgumentException;

function escape(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
}

/** Render a product page for a newly added SKU only.
 * The web server must retain the existing static /catalog/{slug}/index.html pages.
 */
function render(array $product, string $siteOrigin = 'https://aromaresidence.ru'): string {
    $id = $product['id'] ?? null;
    if (!is_string($id) || !preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D', $id)) {
        throw new InvalidArgumentException('Invalid product identifier.');
    }
    if ($siteOrigin !== 'https://aromaresidence.ru') {
        throw new InvalidArgumentException('Canonical host is not configured.');
    }
    $name = trim((string)($product['name'] ?? ''));
    $brand = trim((string)($product['brand'] ?? ''));
    $description = trim((string)($product['description'] ?? ''));
    if ($name === '' || strlen($name) > 250 || $brand === '' || strlen($brand) > 250) {
        throw new InvalidArgumentException('Invalid product content.');
    }
    $heading = trim((string)($product['seoH1'] ?? ''));
    if ($heading === '') $heading = trim((string)($product['title'] ?? ''));
    if ($heading === '') $heading = $name;
    if (strlen($heading) > 300) throw new InvalidArgumentException('Invalid page heading.');
    $title = trim((string)($product['seoTitle'] ?? ''));
    if ($title === '') $title = $name.' на распив — Aroma Residence';
    $summary = trim((string)($product['seoDescription'] ?? ''));
    if ($summary === '') $summary = $description !== '' ? $description : 'Оригинальная парфюмерия на распив в Aroma Residence. Доставка по России.';
    if (strlen($title) > 300 || strlen($summary) > 1800 || strlen($description) > 6000) {
        throw new InvalidArgumentException('Invalid SEO text.');
    }
    $photo = (string)($product['image'] ?? '');
    if (!preg_match('#^/(?:assets/[a-zA-Z0-9_./-]+|media/[a-f0-9-]{36}\.webp)$#D', $photo)
        || str_contains($photo, '..')) {
        $photo = '/assets/emerald-hero.webp';
    }
    $prices = $product['prices'] ?? null;
    if (!is_array($prices)) throw new InvalidArgumentException('Invalid prices.');
    $offers = [];
    foreach ([2, 3, 5, 10, 15] as $ml) {
        $value = $prices[(string)$ml] ?? $prices[$ml] ?? null;
        if ((is_int($value) || (is_float($value) && is_finite($value) && floor($value) === $value)) && $value >= 1 && $value <= 1000000) {
            $offers[(string)$ml] = (int)$value;
        }
    }
    if (!$offers) throw new InvalidArgumentException('Product has no valid volumes.');
    $canonical = $siteOrigin.'/catalog/'.$id.'/';
    $fullImage = $siteOrigin.$photo;
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Product',
        'name' => $name,
        'description' => $summary,
        'image' => [$fullImage],
        'brand' => ['@type' => 'Brand', 'name' => $brand],
        'url' => $canonical,
        'offers' => array_map(static fn(int $ml, int $price):array => [
            '@type'=>'Offer', 'name'=>$ml.' мл', 'url'=>$canonical,
            'price'=>$price, 'priceCurrency'=>'RUB'
        ], array_map('intval', array_keys($offers)), array_values($offers)),
    ];
    $schemaText = json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_HEX_APOS | JSON_THROW_ON_ERROR);
    $sizeButtons = '';
    $first = true;
    foreach ($offers as $ml => $price) {
        $active = $first ? ' active' : '';
        $pressed = $first ? 'true' : 'false';
        $sizeButtons .= '<button type="button" class="'.$active.'" data-page-size="'.escape((string)$ml).'" aria-pressed="'.$pressed.'">'.escape((string)$ml).' мл · '.number_format($price, 0, ',', ' ').' ₽</button>';
        $first = false;
    }
    $hHeading = escape($heading);
    $keywords = trim((string)($product['seoKeywords'] ?? ''));
    $keywordsTag = $keywords !== '' && strlen($keywords) <= 500 ? '<meta name="keywords" content="'.escape($keywords).'">' : '';
    $hName = escape($name);
    $hBrand = escape($brand);
    $hTitle = escape($title);
    $hSummary = escape($summary);
    $hDescription = escape($description ?: $summary);
    $hCanonical = escape($canonical);
    $hPhoto = escape($photo);
    $hFullImage = escape($fullImage);
    $hId = escape($id);
    return <<<HTML
<!doctype html>
<html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0d4c3c"><meta name="robots" content="index,follow,max-image-preview:large">
<title>{$hTitle}</title><meta name="description" content="{$hSummary}">{$keywordsTag}
<link rel="canonical" href="{$hCanonical}">
<meta property="og:type" content="product"><meta property="og:site_name" content="Aroma Residence"><meta property="og:title" content="{$hTitle}">
<meta property="og:description" content="{$hSummary}"><meta property="og:url" content="{$hCanonical}"><meta property="og:image" content="{$hFullImage}">
<meta name="twitter:card" content="summary_large_image">
<link rel="stylesheet" href="/assets/typography.css"><link rel="stylesheet" href="/assets/dynamic-product.css">
<script type="application/ld+json">{$schemaText}</script>
<script src="/assets/cart-finish.js" defer></script><script src="/assets/dynamic-product.js" defer></script>
<link rel="stylesheet" href="/assets/legal-compliance.css"><script src="/assets/legal-compliance.js" defer></script>
</head><body class="ar-dynamic-product emerald-concept">
<header><a class="brand" href="/" aria-label="Aroma Residence — на главную">AROMA RESIDENCE</a><nav aria-label="Главная навигация"><a href="/catalog/">Каталог</a><a href="/sets/">Сеты</a><a href="/cart/">Корзина</a></nav></header>
<main><nav aria-label="Хлебные крошки"><a href="/">Главная</a> / <a href="/catalog/">Каталог</a> / {$hName}</nav>
<section class="ar-dynamic-hero" data-product-page="{$hId}">
<div class="ar-dynamic-picture"><img src="{$hPhoto}" width="800" height="800" alt="{$hName}" fetchpriority="high" decoding="async"></div>
<div><p class="eyebrow">{$hBrand} · ПАРФЮМЕРИЯ НА РАСПИВ</p><h1>{$hHeading}</h1>
<p class="description">{$hDescription}</p><p class="eyebrow">Выберите объём</p>
<div class="ar-dynamic-sizes" role="group" aria-label="Объём флакона">{$sizeButtons}</div>
<button class="ar-dynamic-buy" type="button" data-cart-add="{$hId}">Добавить в корзину</button>
<p class="footnote">Только оригинальная парфюмерия. Подтверждение наличия и доставки — после оформления заявки.</p></div></section></main>
<footer><a href="/dostavka/">Доставка</a><a href="/seller/">Продавец</a><a href="/privacy/">Персональные данные</a><a href="/cookies/">Cookies</a><a href="/returns/">Возврат</a></footer>
</body></html>
HTML;
}
