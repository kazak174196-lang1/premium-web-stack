#!/usr/bin/env node
/** Domain migration for the recovered STATIC Aroma Residence build.
 * Never touches the live Vercel deployment, APIs, product prices, CSS or JavaScript.
 * Dry-run by default; to write pass --apply. Does not publish a website.
 */
import { readFile, writeFile, readdir, stat } from 'node:fs/promises';
import { resolve, join, relative, extname } from 'node:path';
const args = process.argv.slice(2);
const param = (name, fallback) => { const i = args.indexOf(name); return i === -1 ? fallback : args[i+1]; };
const root = resolve(param('--root','src'));
const origin = 'https://aroma-residence-emerald.vercel.app';
const target = 'https://aromaresidence.ru';
const apply = args.includes('--apply');
const accepted = new Set(['.html','.xml','.txt','.json']);
const required = ['index.html','catalog/index.html','cart/index.html','admin/index.html'];
const updates = [], errors = [];
for (const file of required) {
 try { if (!(await stat(join(root,file))).isFile()) errors.push(`Missing required page: ${file}`); }
 catch { errors.push(`Missing required page: ${file}`); }
}
if (errors.length) { console.error(JSON.stringify({root,ok:false,errors},null,2)); process.exit(2); }
async function traverse(dir) {
 for (const entry of await readdir(dir, {withFileTypes:true})) {
  const path = join(dir,entry.name);
  if (entry.isSymbolicLink()) { errors.push(`Symlink not allowed: ${relative(root,path)}`); continue; }
  if (entry.isDirectory()) { if (!['.git','node_modules'].includes(entry.name)) await traverse(path); continue; }
  if (!entry.isFile() || !accepted.has(extname(entry.name))) continue;
  const relativePath = relative(root,path).replaceAll('\\','/');
  const size = (await stat(path)).size;
  if (size>4*1024*1024) { errors.push(`Unexpected text resource size: ${relativePath}`); continue; }
  const content = await readFile(path,'utf8');
  if (content.includes('\ufffd')) { errors.push(`Invalid UTF-8: ${relativePath}`); continue; }
  let output=content.replaceAll(origin,target);
  // This tool is for metadata correction, never delete draft/noindex notices.
  if (content!==output) {
   updates.push(relativePath);
   if (apply) await writeFile(path,output,'utf8');
  }
 }
}
if (!errors.length) await traverse(root);
const report={domain:target,root,mode:apply?'written':'dry-run',filesChanged:updates.length,paths:updates,errors};
console.log(JSON.stringify(report,null,2));
if(errors.length)process.exit(1);
