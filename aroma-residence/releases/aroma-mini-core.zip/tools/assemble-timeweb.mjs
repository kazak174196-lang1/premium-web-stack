#!/usr/bin/env node
/**
 * Deterministic, fail-closed Timeweb Optimo staging assembler.
 * Requires a FULL locally recovered public Aroma Residence snapshot and catalog JSON.
 * Does not upload, publish, enable checkout, or read production secrets.
 */
import {mkdtemp, readdir, stat, lstat, cp, mkdir, copyFile, readFile, writeFile, rm} from 'node:fs/promises';
import {dirname, resolve, join, relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args=process.argv.slice(2);
const arg=n=>{const i=args.indexOf(n);return i>=0?args[i+1]:undefined;};
const staticRoot=arg('--static')?resolve(arg('--static')):null;
const dataRoot=arg('--data')?resolve(arg('--data')):null;
const destination=arg('--out')?resolve(arg('--out')):null;
const required=['index.html','catalog/index.html','sets/index.html','cart/index.html','admin/index.html','sitemap.xml','assets/catalog-data.json'];
const fatal=message=>{console.error('ERROR:',message);process.exitCode=1;};
if (!staticRoot||!dataRoot||!destination){fatal('Usage: node tools/assemble-timeweb.mjs --static <restored-html-root> --data <restored-private-data-root> --out <NEW release-folder>');}
else {
 let temp;
 try {
  for(const p of required){if(!(await stat(join(staticRoot,p))).isFile())throw Error('Missing baseline file: '+p);}
  const catalogFile=join(dataRoot,'catalog.json');
  const data=JSON.parse(await readFile(catalogFile,'utf8'));
  if(!Array.isArray(data.products)||data.products.length<90)throw Error('Incomplete catalogue: need original 91+ products');
  if(await stat(destination).then(()=>true,()=>false))throw Error('Destination already exists; refusing to overwrite it');
  // Do not copy a filesystem with symlinks, devices, or recursive mounts.
  const walk=async folder=>{for(const ent of await readdir(folder,{withFileTypes:true})){
    const f=join(folder,ent.name),s=await lstat(f);
    if(s.isSymbolicLink())throw Error('Symlink in input: '+f);
    if(ent.isDirectory())await walk(f); else if(!ent.isFile())throw Error('Unexpected filesystem entry: '+f);
  }};
  await walk(staticRoot);await walk(dataRoot);
  const images=await readdir(join(staticRoot,'assets','products')).catch(()=>[]);
  if(images.filter(f=>f.endsWith('.webp')).length<90)throw Error('Incomplete product photos; refusing release');
  temp=await mkdtemp(join(tmpdir(),'aroma-release-'));
  const webroot=join(temp,'public_html'),privateDir=join(temp,'.aroma_private');
  await cp(staticRoot,webroot,{recursive:true,force:false,errorOnExist:true});
  await mkdir(privateDir,{recursive:true});await mkdir(join(privateDir,'lib'),{recursive:true});
  await copyFile(catalogFile,join(privateDir,'catalog.json'));
  for(const name of ['Commerce.php','ProductPage.php'])await copyFile(join(project,'private','lib',name),join(privateDir,'lib',name));
  await copyFile(join(project,'private','config.example.php'),join(privateDir,'config.example.php'));
  await cp(join(project,'public','api'),join(webroot,'api'),{recursive:true});
  await cp(join(project,'public','media'),join(webroot,'media'),{recursive:true});
  await copyFile(join(project,'public','catalog-product.php'),join(webroot,'catalog-product.php'));
  for(const name of await readdir(join(project,'assets'))){await copyFile(join(project,'assets',name),join(webroot,'assets',name));}
  if(await stat(join(webroot,'.htaccess')).then(()=>true,()=>false))throw Error('Existing .htaccess requires manual comparison; refusing to overwrite');
  await copyFile(join(project,'templates','https-ready.htaccess'),join(webroot,'.htaccess'));
  for(const tool of [
    ['patch-compliance.cjs','--root',webroot,'--config',join(project,'compliance.config.json')],
    ['tools/rebase-domain.mjs','--root',webroot,'--apply']
  ]){
    const [name,...rest]=tool;
    const result=spawnSync(process.execPath,[join(project,name),...rest],{encoding:'utf8',timeout:30000});
    if(result.status!==0)throw Error(name+' failed: '+(result.stderr||result.stdout||result.status));
  }
  // Do not expose unfinished store to search engines during DNS/SSL staging.
  await writeFile(join(webroot,'robots.txt'),'User-agent: *\nDisallow: /\n# PRELAUNCH ONLY: activate reviewed robots after completing release checklist\n');
  const pages=(await readdir(join(webroot,'catalog'),{withFileTypes:true})).filter(x=>x.isDirectory()).length;
  if(pages<90)throw Error('Product HTML pages missing from staged copy');
  const missing=[];
  const sitemap=await readFile(join(webroot,'sitemap.xml'),'utf8');
  for(const found of sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)){
    const url=new URL(found[1]);if(url.host!=='aromaresidence.ru')throw Error('Sitemap has wrong host: '+url.host);
    const p=join(webroot,url.pathname,url.pathname.endsWith('/')?'index.html':'');
    if(!(await stat(p).then(()=>true,()=>false)))missing.push(url.pathname);
  }
  if(missing.length)throw Error('Broken sitemap routes: '+missing.join(', '));
  const manifest={domain:'https://aromaresidence.ru',mode:'prelaunch',products:data.products.length,staticProductFolders:pages,
    sitemapLinks:[...sitemap.matchAll(/<loc>/g)].length,baselineStatus:'recovered',phpApi:'included-not-configured',database:'not-connected',ordersEnabled:false,
    limitations:['Original admin and storefront JS are retained','MySQL migration not applied','Legal and operational gates still need approval','Full E2E requires live Timeweb test deployment']};
  await writeFile(join(temp,'RELEASE_REPORT.json'),JSON.stringify(manifest,null,2)+'\n');
  await copyFile(join(project,'INSTALL.md'),join(temp,'INSTALL.md'));
  await copyFile(join(project,'DOMAIN_SETUP.md'),join(temp,'DOMAIN_SETUP.md'));
  await mkdir(dirname(destination),{recursive:true});
  // Fails closed on pre-existing destination and creates output only after all checks pass.
  const {rename}=await import('node:fs/promises');await rename(temp,destination);temp=null;
  console.log(JSON.stringify({ok:true,destination,...manifest},null,2));
 }catch(error){fatal(error.message)}
 finally{if(temp)await rm(temp,{recursive:true,force:true});}
}
