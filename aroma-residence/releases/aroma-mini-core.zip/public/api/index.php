<?php
declare(strict_types=1);
/**
 * Aroma Residence — Timeweb shared-hosting PHP 8.2+ API adapter.
 * Fails closed: no checkout until all release gates are explicitly confirmed.
 * Existing frontend uses /api/{catalog,checkout-status,quote,orders,admin,promo-status}.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');

use Aroma\Commerce\InvalidOrder;
use function Aroma\Commerce\catalogMap;
use function Aroma\Commerce\priceOrder;

function respond(int $code,array $data):never {http_response_code($code);echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);exit;}
function requestBody(int $limit=65536):array {
    $size=isset($_SERVER['CONTENT_LENGTH'])?(int)$_SERVER['CONTENT_LENGTH']:0;
    if ($size>$limit) respond(413,['error'=>'Слишком большой запрос.']);
    $content=file_get_contents('php://input',false,null,0,$limit+1);
    if ($content===false || strlen($content)>$limit) respond(413,['error'=>'Слишком большой запрос.']);
    try{$data=json_decode($content,true,64,JSON_THROW_ON_ERROR);}catch(Throwable){respond(400,['error'=>'Некорректный JSON.']);}
    if (!is_array($data) || array_is_list($data)) respond(400,['error'=>'Ожидается JSON-объект.']);
    return $data;
}
function method(string $expected):void {if (($_SERVER['REQUEST_METHOD']??'GET')!==$expected) {header('Allow: '.$expected);respond(405,['error'=>'Метод не поддерживается.']);}}
function sameOrigin(array $cfg):void {
    $expected=rtrim((string)($cfg['siteOrigin']??''),'/');
    if (!preg_match('~^https://[a-z0-9.-]+$~D',$expected)) respond(503,['error'=>'Настройка домена не завершена.']);
    $origin=(string)($_SERVER['HTTP_ORIGIN']??'');
    if ($origin!=='' && !hash_equals($expected,$origin)) respond(403,['error'=>'Запрос с чужого сайта отклонён.']);
    $fetchSite=(string)($_SERVER['HTTP_SEC_FETCH_SITE']??'');
    if (in_array($fetchSite,['cross-site','same-site'],true)) respond(403,['error'=>'Недопустимый источник запроса.']);
}
function cfgReady(array $cfg):bool {
    $db=$cfg['database']??[];
    return !empty($db['dsn']) && !empty($db['username']) && !empty($db['password'])
        && !str_contains((string)$db['username'],'REPLACE') && !str_contains((string)$db['password'],'REPLACE')
        && strlen((string)($cfg['sessionHmacSecret']??''))>=64;
}
function ordersReady(array $cfg):bool {
    return cfgReady($cfg) && ($cfg['ordersEnabled']??false)===true && ($cfg['rknConfirmed']??false)===true
        && ($cfg['russianStorageConfirmed']??false)===true && ($cfg['markingConfirmed']??false)===true
        && ($cfg['fiscalizationConfirmed']??false)===true;
}
function database(array $cfg):PDO {
    if (!cfgReady($cfg)) respond(503,['error'=>'Хранилище заказов пока не подключено.']);
    try {
        $db=new PDO($cfg['database']['dsn'],$cfg['database']['username'],$cfg['database']['password'],[
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false,
            PDO::ATTR_TIMEOUT=>5,
        ]);
        $db->exec("SET time_zone = '+00:00'");
        return $db;
    } catch(PDOException $e) {
        error_log('Aroma Residence database connectivity error (no customer data)');
        respond(503,['error'=>'Сервис временно недоступен. Повторите попытку позже.']);
    }
}
function fetchCatalog(array $cfg,?PDO $db=null):array {
    $base=dirname(__DIR__,2).'/.aroma_private/catalog.json';
    if (!is_file($base)) respond(503,['error'=>'Каталог пока не перенесён.']);
    try{$data=json_decode((string)file_get_contents($base),true,32,JSON_THROW_ON_ERROR);}catch(Throwable){respond(503,['error'=>'Не удалось загрузить каталог.']);}
    if (!is_array($data) || !isset($data['products']) || !is_array($data['products'])) respond(503,['error'=>'Каталог недоступен.']);
    if ($db!==null) {
        $p=$db->query('SELECT id,payload FROM aroma_catalog_edits')->fetchAll();
        $overrides=[];
        foreach ($p as $row) {try{$overrides[$row['id']]=json_decode($row['payload'],true,32,JSON_THROW_ON_ERROR);}catch(Throwable){continue;}}
        $found=[];
        foreach ($data['products'] as &$product) {if (!empty($product['id']) && isset($overrides[$product['id']])) {$product=array_replace($product,$overrides[$product['id']]);$found[$product['id']]=true;}}
        unset($product);
        foreach ($overrides as $id=>$value) if (!isset($found[$id]) && is_array($value)) $data['products'][]=$value;
        $s=$db->query('SELECT id,payload FROM aroma_catalog_sets')->fetchAll();
        $sets=[];
        foreach ($data['sets']??[] as $set) if(is_array($set) && isset($set['id']))$sets[$set['id']]=$set;
        foreach($s as $row){try{$set=json_decode($row['payload'],true,32,JSON_THROW_ON_ERROR);$sets[$row['id']]=$set;}catch(Throwable){continue;}}
        $data['sets']=array_values($sets);
    }
    try{catalogMap($data['products']);}catch(InvalidOrder){respond(503,['error'=>'Ошибка данных каталога.']);}
    return ['products'=>$data['products'],'sets'=>$data['sets']??[]];
}
function rateLimit(PDO $db,array $cfg,string $name,int $limit,int $seconds):void {
    $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
    $key=hash_hmac('sha256',$name.':'.$ip,(string)$cfg['sessionHmacSecret']);
    $db->prepare('DELETE FROM aroma_rate_limits WHERE bucket_hash=? AND expires_at<UTC_TIMESTAMP()')->execute([$key]);
    $stmt=$db->prepare('INSERT INTO aroma_rate_limits(bucket_hash,hits,expires_at) VALUES (?,1,DATE_ADD(UTC_TIMESTAMP(),INTERVAL '.(int)$seconds.' SECOND)) ON DUPLICATE KEY UPDATE hits=hits+1');
    $stmt->execute([$key]);
    $stmt=$db->prepare('SELECT hits FROM aroma_rate_limits WHERE bucket_hash=?');$stmt->execute([$key]);
    if ((int)$stmt->fetchColumn()>$limit) respond(429,['error'=>'Слишком много запросов. Повторите позже.']);
}
function cookieSecure():bool {return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || (($_SERVER['SERVER_PORT']??'')==='443');}
function sessionCookie(string $value,int $expires):void {
    setcookie('aroma_admin',$value,['expires'=>$expires,'path'=>'/api','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);
}
function authenticate(PDO $db):void {
    $cookie=$_COOKIE['aroma_admin']??'';
    if (!is_string($cookie) || !preg_match('/^[a-f0-9]{64}$/D',$cookie)) respond(401,['error'=>'Требуется вход администратора.']);
    $hash=hash('sha256',$cookie);
    $stmt=$db->prepare('SELECT token_hash FROM aroma_sessions WHERE token_hash=? AND expires_at>UTC_TIMESTAMP() LIMIT 1');
    $stmt->execute([$hash]);
    if (!$stmt->fetchColumn()) respond(401,['error'=>'Время сеанса истекло. Войдите снова.']);
}
function userOrders(PDO $db,int $limit=100):array {
    $limit=max(1,min(100,$limit));
    $rows=$db->query('SELECT * FROM aroma_orders ORDER BY created_at DESC LIMIT '.$limit)->fetchAll();
    $out=[];
    foreach($rows as $row){
        try{$items=json_decode($row['items'],true,32,JSON_THROW_ON_ERROR);$addr=$row['address']!==null?json_decode($row['address'],true,32,JSON_THROW_ON_ERROR):null;}catch(Throwable){$items=[];$addr=null;}
        $out[]=['id'=>$row['id'],'orderId'=>'AR-'.str_pad((string)$row['order_number'],7,'0',STR_PAD_LEFT),'createdAt'=>str_replace(' ','T',$row['created_at']).'Z','name'=>$row['name'],'phone'=>$row['phone'],'email'=>$row['email'],'delivery'=>$row['delivery'],'address'=>$addr,'comment'=>$row['comment'],'items'=>$items,'total'=>(int)$row['total'],'subtotal'=>(int)$row['subtotal'],'setDiscount'=>(int)$row['set_discount'],'promoCode'=>$row['promo_code'],'status'=>$row['status']];
    }
    return $out;
}
function previewPrice(array $cfg,array $body,?PDO $db=null):array {
    $catalog=fetchCatalog($cfg,$db);
    $data=array_replace($body,['name'=>'Предварительный расчёт','phone'=>'+79990000000','consent'=>true,'delivery'=>'quote']);
    return priceOrder($data,catalogMap($catalog['products']));
}
function promoPrice(PDO $db,string $code,array $priced,bool $forOrder=false):array {
    if ($code==='')return ['discount'=>0,'promo'=>null];
    $query='SELECT * FROM aroma_promo_codes WHERE code=?'.($forOrder?' FOR UPDATE':'');
    $stmt=$db->prepare($query);$stmt->execute([$code]);$record=$stmt->fetch();
    if (!$record || (int)$record['active']!==1) throw new InvalidOrder('Промокод неактивен.');
    if ($record['starts_at']!==null && strtotime($record['starts_at'].' UTC')>time()) throw new InvalidOrder('Промокод пока не действует.');
    if ($record['expires_at']!==null && strtotime($record['expires_at'].' UTC')<time()) throw new InvalidOrder('Срок промокода истёк.');
    if ((int)$record['max_uses']>0 && (int)$record['used']>=(int)$record['max_uses']) throw new InvalidOrder('Лимит использований промокода исчерпан.');
    $eligible=0;
    foreach($priced['items'] as $item)if($item['setId']===null)$eligible+=$item['lineTotal'];
    if ($eligible<(int)$record['min_amount']) throw new InvalidOrder('Сумма покупки недостаточна для промокода.');
    $percent=(int)$record['percent'];
    if ($percent<1 || $percent>50 || $eligible===0) throw new InvalidOrder('Промокод неприменим к этому заказу.');
    $discount=(int)round($eligible*$percent/100,0,PHP_ROUND_HALF_UP);
    return ['discount'=>$discount,'promo'=>['code'=>$code,'percent'=>$percent]];
}
function uuidv4():string {
    $bytes=random_bytes(16);$bytes[6]=chr((ord($bytes[6])&0x0f)|0x40);$bytes[8]=chr((ord($bytes[8])&0x3f)|0x80);
    $h=bin2hex($bytes);
    return substr($h,0,8).'-'.substr($h,8,4).'-'.substr($h,12,4).'-'.substr($h,16,4).'-'.substr($h,20);
}
function admin(array $cfg):never {
    $db=database($cfg);
    if (($_SERVER['HTTP_X_AROMA_ADMIN']??'')!=='1') respond(403,['error'=>'Отсутствует заголовок панели администратора.']);
    $action=(string)($_GET['action']??'dashboard');
    if ($action==='login') {
        method('POST');sameOrigin($cfg);
        if (!cookieSecure()) respond(503,['error'=>'Для входа требуется HTTPS.']);
        rateLimit($db,$cfg,'admin-login',12,900);
        $body=requestBody(2048);$password=$body['password']??null;
        $hash=(string)($cfg['adminPasswordHash']??'');
        if (!is_string($password) || strlen($password)>256 || $hash==='' || !password_verify($password,$hash)) respond(401,['error'=>'Неверный пароль.']);
        $session=bin2hex(random_bytes(32));$hashed=hash('sha256',$session);
        $db->prepare('INSERT INTO aroma_sessions(token_hash,expires_at) VALUES (?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 8 HOUR))')->execute([$hashed]);
        sessionCookie($session,time()+28800);
        respond(200,['ok'=>true]);
    }
    authenticate($db);
    if ($action==='logout') {
        method('POST');sameOrigin($cfg);
        $hash=hash('sha256',(string)$_COOKIE['aroma_admin']);
        $db->prepare('DELETE FROM aroma_sessions WHERE token_hash=?')->execute([$hash]);
        sessionCookie('',time()-3600);respond(200,['ok'=>true]);
    }
    if ($action==='dashboard') {method('GET');$cat=fetchCatalog($cfg,$db);respond(200,['products'=>$cat['products'],'sets'=>$cat['sets'],'orders'=>userOrders($db,20)]);}
    if ($action==='orders') {method('GET');respond(200,['orders'=>userOrders($db,100)]);}
    if ($action==='order') {
        method('PATCH');sameOrigin($cfg);$data=requestBody(1024);
        $id=$data['id']??null;$status=$data['status']??null;
        if (!is_string($id) || !preg_match('/^[a-f0-9-]{36}$/D',$id) || !in_array($status,['new','processing','completed','cancelled'],true))respond(422,['error'=>'Некорректный статус или номер заказа.']);
        $db->beginTransaction();
        try {
            $stmt=$db->prepare('SELECT status FROM aroma_orders WHERE id=? FOR UPDATE');$stmt->execute([$id]);$old=$stmt->fetchColumn();
            if ($old===false){$db->rollBack();respond(404,['error'=>'Заказ не найден.']);}
            if($old!==$status){$db->prepare('UPDATE aroma_orders SET status=? WHERE id=?')->execute([$status,$id]);$db->prepare('INSERT INTO aroma_status_audit(order_id,old_status,new_status) VALUES(?,?,?)')->execute([$id,$old,$status]);}
            $db->commit();respond(200,['ok'=>true,'status'=>$status]);
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    }
    if ($action==='product') {
        method('PUT');sameOrigin($cfg);$p=requestBody(24000);
        $id=$p['id']??null;
        if (!is_string($id) || !preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D',$id))respond(422,['error'=>'Неверный URL товара.']);
        foreach(['name','brand','description','image'] as $field)if(!isset($p[$field]) || !is_string($p[$field]) || strlen($p[$field])>($field==='description'?4000:500))respond(422,['error'=>'Некорректное поле: '.$field]);
        if ($p['image']!=='' && !preg_match('#^/(?:assets/[a-zA-Z0-9_./-]+|media/[a-f0-9-]{36}\.webp)$#D',$p['image']))respond(422,['error'=>'Некорректное изображение.']);
        foreach(['title','seoTitle','seoDescription','seoKeywords','seoH1'] as $key){$p[$key]=isset($p[$key]) && is_string($p[$key])?trim($p[$key]):'';if(strlen($p[$key])>1000)respond(422,['error'=>'Слишком длинное SEO-поле.']);}
        if (!isset($p['prices']) || !is_array($p['prices']))respond(422,['error'=>'Укажите цены товара.']);
        $prices=[];foreach($p['prices'] as $ml=>$value){$key=(string)$ml;if(!in_array($key,['2','3','5','10','15'],true) || !is_int($value) || $value<1 || $value>1000000)respond(422,['error'=>'Некорректная цена.']);$prices[$key]=$value;}
        if(!$prices)respond(422,['error'=>'Нужен хотя бы один доступный объём.']);
        $p['prices']=$prices;$p['id']=$id;
        $db->prepare('INSERT INTO aroma_catalog_edits(id,payload) VALUES(?,?) ON DUPLICATE KEY UPDATE payload=VALUES(payload)')->execute([$id,json_encode($p,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
        respond(200,['ok'=>true,'product'=>$p]);
    }
    if ($action==='set') {
        method('PUT');sameOrigin($cfg);$s=requestBody(20000);
        $id=$s['id']??null;
        if(!is_string($id) || !preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D',$id))respond(422,['error'=>'Некорректный ID сета.']);
        foreach(['title','description','image'] as $field)if(!isset($s[$field]) || !is_string($s[$field]) || strlen($s[$field])>2500)respond(422,['error'=>'Некорректное поле сета.']);
        if(!isset($s['price']) || !is_int($s['price']) || $s['price']<0 || $s['price']>2000000)respond(422,['error'=>'Некорректная цена набора.']);
        $s['visible']=($s['visible']??false)===true;
        $db->prepare('INSERT INTO aroma_catalog_sets(id,payload) VALUES(?,?) ON DUPLICATE KEY UPDATE payload=VALUES(payload)')->execute([$id,json_encode($s,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
        respond(200,['ok'=>true]);
    }
    if ($action==='upload') {
        method('POST');sameOrigin($cfg);
        if ((int)($_SERVER['CONTENT_LENGTH']??0)>2097152)respond(413,['error'=>'Изображение превышает 2 МБ.']);
        $bytes=file_get_contents('php://input',false,null,0,2097153);
        if ($bytes===false || strlen($bytes)<24 || strlen($bytes)>2097152 || substr($bytes,0,4)!=='RIFF' || substr($bytes,8,4)!=='WEBP')respond(422,['error'=>'Недопустимый файл WebP.']);
        $image=@getimagesizefromstring($bytes);
        if (!$image || ($image['mime']??'')!=='image/webp' || $image[0]<1 || $image[1]<1 || $image[0]>6000 || $image[1]>6000)respond(422,['error'=>'Изображение повреждено или слишком велико.']);
        $media=dirname(__DIR__).'/media';
        if (!is_dir($media))respond(503,['error'=>'Каталог изображений не настроен.']);
        $id=uuidv4();$dest=$media.'/'.$id.'.webp';
        $file=fopen($dest,'x');if($file===false)respond(503,['error'=>'Не удалось сохранить изображение.']);
        try{if(fwrite($file,$bytes)!==strlen($bytes)){fclose($file);unlink($dest);respond(503,['error'=>'Ошибка записи фото.']);}fclose($file);chmod($dest,0644);}catch(Throwable $e){if(is_resource($file))fclose($file);@unlink($dest);throw $e;}
        respond(200,['url'=>'/media/'.$id.'.webp']);
    }
    if ($action==='promos') {
        $m=(string)($_SERVER['REQUEST_METHOD']??'GET');
        if($m==='GET'){
            $rows=$db->query('SELECT * FROM aroma_promo_codes ORDER BY updated_at DESC LIMIT 100')->fetchAll();
            $out=[];foreach($rows as $r)$out[]=['code'=>$r['code'],'description'=>$r['description'],'percent'=>(int)$r['percent'],'minAmount'=>(int)$r['min_amount'],'maxUses'=>(int)$r['max_uses'],'used'=>(int)$r['used'],'startsAt'=>$r['starts_at'],'expiresAt'=>$r['expires_at'],'active'=>(int)$r['active']===1];
            respond(200,['promos'=>$out]);
        }
        sameOrigin($cfg);
        if($m==='DELETE'){
            $code=(string)($_GET['code']??'');if(!preg_match('/^[A-Z0-9_-]{3,32}$/D',$code))respond(422,['error'=>'Некорректный промокод.']);
            $db->prepare('DELETE FROM aroma_promo_codes WHERE code=?')->execute([$code]);respond(200,['ok'=>true]);
        }
        if($m==='PUT'){
            $p=requestBody(4096);$code=$p['code']??null;
            if(!is_string($code) || !preg_match('/^[A-Z0-9_-]{3,32}$/D',$code))respond(422,['error'=>'Некорректный промокод.']);
            $percent=$p['percent']??null;$min=$p['minAmount']??null;$max=$p['maxUses']??null;
            if(!is_int($percent)||$percent<1||$percent>50||!is_int($min)||$min<0||$min>50000000||!is_int($max)||$max<0||$max>1000000)respond(422,['error'=>'Некорректные ограничения скидки.']);
            $description=$p['description']??'';if(!is_string($description)||strlen($description)>160)respond(422,['error'=>'Слишком длинное описание.']);
            $dates=[];
            foreach(['startsAt','expiresAt'] as $key){$v=$p[$key]??'';if(!is_string($v)||($v!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/D',$v)))respond(422,['error'=>'Некорректная дата.']);$dates[]=$v!==''?str_replace('T',' ',$v).':00':null;}
            $db->prepare('INSERT INTO aroma_promo_codes(code,description,percent,min_amount,max_uses,starts_at,expires_at,active) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE description=VALUES(description),percent=VALUES(percent),min_amount=VALUES(min_amount),max_uses=VALUES(max_uses),starts_at=VALUES(starts_at),expires_at=VALUES(expires_at),active=VALUES(active)')
              ->execute([$code,$description,$percent,$min,$max,$dates[0],$dates[1],($p['active']??false)===true?1:0]);
            respond(200,['ok'=>true]);
        }
        respond(405,['error'=>'Метод не поддерживается.']);
    }
    respond(404,['error'=>'Неизвестное действие администратора.']);
}
try {
    $path=(string)(parse_url((string)($_SERVER['REQUEST_URI']??''),PHP_URL_PATH)??'');
    $route=trim($path,'/');
    if (!preg_match('#^api/(?:catalog|checkout-status|promo-status|quote|orders|admin)$#D',$route))respond(404,['error'=>'Неизвестный API.']);
    $configPath=dirname(__DIR__,2).'/.aroma_private/config.php';
    if (!is_file($configPath)) {
        if ($route==='api/checkout-status')respond(200,['emailOrdersAvailable'=>false]);
        if ($route==='api/promo-status')respond(200,['available'=>false]);
        respond(503,['error'=>'Сервис ещё не настроен.']);
    }
    $cfg=require $configPath;
    if (!is_array($cfg))respond(503,['error'=>'Конфигурация сервиса не настроена.']);
    require dirname(__DIR__,2).'/.aroma_private/lib/Commerce.php';
    if ($route==='api/checkout-status') {method('GET');respond(200,['emailOrdersAvailable'=>ordersReady($cfg)]);}
    if ($route==='api/promo-status') {method('GET');respond(200,['available'=>ordersReady($cfg)]);}
    if ($route==='api/catalog') {
        method('GET');$db=cfgReady($cfg)?database($cfg):null;respond(200,fetchCatalog($cfg,$db));
    }
    if ($route==='api/admin')admin($cfg);
    if ($route==='api/quote') {
        method('POST');sameOrigin($cfg);$raw=requestBody(30000);
        $db=ordersReady($cfg)?database($cfg):null;
        $price=previewPrice($cfg,$raw,$db);
        $discount=0;$promo=null;
        if($price['promoCode']!==''){
            if(!$db)respond(503,['error'=>'Промокоды пока не доступны.']);
            $out=promoPrice($db,$price['promoCode'],$price);
            $discount=$out['discount'];$promo=$out['promo'];
        }
        respond(200,['subtotal'=>$price['subtotal'],'setDiscount'=>$price['setDiscount'],'promoDiscount'=>$discount,'total'=>$price['total']-$discount,'promo'=>$promo]);
    }
    if ($route==='api/orders') {
        method('POST');sameOrigin($cfg);
        if (!ordersReady($cfg))respond(503,['error'=>'Онлайн-оформление пока не подключено. Можно скопировать заказ и отправить его магазину ВКонтакте.']);
        $db=database($cfg);rateLimit($db,$cfg,'orders',15,3600);
        $raw=requestBody(40000);
        $catalog=fetchCatalog($cfg,$db);
        $price=priceOrder($raw,catalogMap($catalog['products']));
        $secret=(string)$cfg['sessionHmacSecret'];
        $identity=json_encode($price['identity'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
        $dedupe=hash_hmac('sha256',$identity,$secret);
        $lockName='aroma_order_'.substr($dedupe,0,40);
        $lock=$db->prepare('SELECT GET_LOCK(?,2)');$lock->execute([$lockName]);
        if((int)$lock->fetchColumn()!==1)respond(503,['error'=>'Заказ обрабатывается. Повторите через несколько секунд.']);
        try {
            $db->beginTransaction();
            $s=$db->prepare('SELECT order_number,total FROM aroma_orders WHERE dedupe_hash=? AND created_at>DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) ORDER BY created_at DESC LIMIT 1');
            $s->execute([$dedupe]);$prior=$s->fetch();
            if($prior){
                $db->commit();
                $outStatus=200;
                $outBody=['ok'=>true,'orderId'=>'AR-'.str_pad((string)$prior['order_number'],7,'0',STR_PAD_LEFT),'total'=>(int)$prior['total'],'duplicate'=>true];
            } else {
            $promo=promoPrice($db,$price['promoCode'],$price,true);
            $total=$price['total']-$promo['discount'];
            if($total<0)throw new InvalidOrder('Некорректный итог заказа.');
            $id=uuidv4();
            $consentPath=dirname(__DIR__).'/consent/index.html';
            $consentDigest=is_file($consentPath)?hash_file('sha256',$consentPath):hash('sha256','Aroma Residence '.(string)($cfg['consentVersion']??'2026-11-16'));
            if(!is_string($consentDigest)) throw new RuntimeException('Consent document unavailable');
            $q=$db->prepare('INSERT INTO aroma_orders(id,name,phone,email,delivery,address,comment,items,subtotal,set_discount,promo_code,promo_discount,total,dedupe_hash,consent_version,consent_sha256) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $q->execute([$id,$price['name'],$price['phone'],$price['email'],$price['delivery'],json_encode($price['address'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$price['comment'],json_encode($price['items'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$price['subtotal'],$price['setDiscount'],$price['promoCode'],$promo['discount'],$total,$dedupe,(string)$cfg['consentVersion'],$consentDigest]);
            $num=(int)$db->lastInsertId();
            if($price['promoCode']!=='')$db->prepare('UPDATE aroma_promo_codes SET used=used+1 WHERE code=?')->execute([$price['promoCode']]);
            $db->commit();
            $outStatus=201;
            $outBody=['ok'=>true,'orderId'=>'AR-'.str_pad((string)$num,7,'0',STR_PAD_LEFT),'total'=>$total];
            }
        }finally {
            if($db->inTransaction())$db->rollBack();
            $db->prepare('SELECT RELEASE_LOCK(?)')->execute([$lockName]);
        }
        respond($outStatus,$outBody);
    }
} catch(InvalidOrder $e) {
    respond(422,['error'=>$e->getMessage()]);
} catch(Throwable $e) {
    error_log('Aroma Residence API error: '.get_class($e).' / no input values logged');
    respond(503,['error'=>'Не удалось выполнить запрос. Повторите позже.']);
}
