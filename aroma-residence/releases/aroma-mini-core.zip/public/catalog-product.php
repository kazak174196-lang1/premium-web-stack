<?php
declare(strict_types=1);
/** Fallback PHP route only for newly-added products not present in static /catalog/<slug>/ pages. */
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
$slug = $_GET['slug'] ?? '';
if (!is_string($slug) || !preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D', $slug)) {
    http_response_code(404); exit('Товар не найден');
}
$private = dirname(__DIR__).'/.aroma_private';
$configPath = $private.'/config.php';
if (!is_file($configPath)) {
    header('Cache-Control: no-store'); http_response_code(503); exit('Каталог временно недоступен');
}
try {
    $config = require $configPath;
    $dbInfo = $config['database'] ?? null;
    if (!is_array($config) || !is_array($dbInfo)
        || !isset($dbInfo['dsn'], $dbInfo['username'], $dbInfo['password'])
        || str_contains((string)$dbInfo['username'],'REPLACE')
        || str_contains((string)$dbInfo['password'],'REPLACE')) {
        throw new RuntimeException('Database not configured');
    }
    $pdo = new PDO((string)$dbInfo['dsn'], (string)$dbInfo['username'], (string)$dbInfo['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 5,
    ]);
    $query = $pdo->prepare('SELECT payload FROM aroma_catalog_edits WHERE id=? LIMIT 1');
    $query->execute([$slug]);
    $data = $query->fetchColumn();
    if ($data === false) { http_response_code(404); exit('Товар не найден'); }
    $product = json_decode((string)$data, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($product) || ($product['id'] ?? null) !== $slug) throw new RuntimeException('Invalid stored product');
    require $private.'/lib/ProductPage.php';
    $page = \Aroma\ProductPage\render($product);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: public, max-age=120, stale-while-revalidate=240');
    echo $page;
} catch (Throwable $exception) {
    error_log('Aroma product page render failed: '.get_class($exception));
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo 'Страница временно недоступна. Попробуйте позже.';
}
