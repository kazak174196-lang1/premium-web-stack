'use strict';
/**
 * Additive legal release patch for Aroma Residence.
 * Idempotent; modifies only HTML pages and adds new dedicated static assets.
 * Production mode fails closed if operator/compliance data are missing.
 * Usage: node patch-compliance.cjs --root src --config compliance.config.json [--production]
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const args = process.argv.slice(2);
const arg = (name, fallback) => {
  const index = args.indexOf(name);
  return index < 0 || !args[index + 1] || args[index + 1].startsWith('--') ? fallback : args[index + 1];
};
const root = path.resolve(arg('--root', 'src'));
const cfgFile = path.resolve(arg('--config', 'compliance.config.json'));
const production = args.includes('--production');
const dryRun = args.includes('--dry-run');
if (!fs.existsSync(cfgFile)) throw new Error('Отсутствует compliance.config.json');
const cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
const operator = cfg.operator || {};
const processOptions = cfg.processing || {};
const store = cfg.store || {};
const missing = [];
const isIndividualEntrepreneur = /^\s*(?:ИП|индивидуальный предприниматель)\s*$/i.test(String(operator.legalForm || ''));

for (const key of ['legalName','legalForm','inn','ogrn','businessEmail','personalDataEmail','contactPhone']) {
  if (!String(operator[key] || '').trim()) missing.push(`operator.${key}`);
}
if (!isIndividualEntrepreneur && !String(operator.legalAddress || '').trim()) missing.push('operator.legalAddress');
if (!String(processOptions.hostCompany || '').trim()) missing.push('processing.hostCompany');
if (!/^https:\/\/[^\s/]+/.test(String(cfg.siteUrl || ''))) missing.push('siteUrl (HTTPS)');
for (const key of ['businessEmail','personalDataEmail']) { if (operator[key] && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(operator[key])) missing.push(`operator.${key} (email)`); }
if (operator.inn && !/^(\d{10}|\d{12})$/.test(operator.inn)) missing.push('operator.inn (10 или 12 цифр)');
if (operator.ogrn && !/^(\d{13}|\d{15})$/.test(operator.ogrn)) missing.push('operator.ogrn (13 или 15 цифр)');
if (isIndividualEntrepreneur && operator.inn && !/^\d{12}$/.test(operator.inn)) missing.push('operator.inn (12 цифр для ИП)');
if (isIndividualEntrepreneur && operator.ogrn && !/^\d{15}$/.test(operator.ogrn)) missing.push('operator.ogrn (15 цифр для ИП)');
if (processOptions.hostCountry !== 'Россия' || processOptions.hostingLocationConfirmed !== true) missing.push('processing.hostingLocationConfirmed');
if (!['none','approved_process'].includes(processOptions.crossBorderTransfers)) missing.push('processing.crossBorderTransfers');
if (!['filed','documented_exception'].includes(processOptions.roskomnadzorNoticeStatus)) missing.push('processing.roskomnadzorNoticeStatus');
for (const key of ['registeredBusinessConfirmed','markingComplianceConfirmed','receiptsComplianceConfirmed','deliveryTermsApproved','returnsTermsApproved']) {
  if (store[key] !== true) missing.push(`store.${key}`);
}
for (const type of ['analytics', 'marketing']) {
  if (processOptions[`${type}Enabled`] === true && (!(processOptions[`${type}Providers`] || []).length || processOptions.cookiesGatingVerified !== true)) {
    missing.push(`processing.${type}Providers + cookiesGatingVerified`);
  }
}
if (production && (cfg.status !== 'approved' || missing.length)) {
  throw new Error('Релиз заблокирован: ' + [...(cfg.status !== 'approved' ? ['status=approved'] : []), ...missing].join(', '));
}
if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) throw new Error('Каталог сборки не найден: ' + root);
const approved = cfg.status === 'approved' && missing.length === 0;
const draft = !approved;

const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const esc = escapeHtml;
const name = operator.legalName ? esc(operator.legalName) : 'Сведения о продавце ещё не подтверждены';
const field = (key) => operator[key] ? esc(operator[key]) : 'Требует заполнения перед публикацией';
const stamp = cfg.schemaVersion || '2026-11-16';
const heading = (text) => `<section><h2>${esc(text)}</h2>`;
const draftWarning = draft ? '<div class="ar-legal-draft" role="note">ПРОЕКТ ДОКУМЕНТА. Данные продавца и юридические требования не подтверждены. Страница не предназначена для публичного использования до завершения проверки.</div>' : '';
const list = (entries) => `<ul>${entries.map(s=>`<li>${s}</li>`).join('')}</ul>`;
const email = () => operator.personalDataEmail ? `<a href="mailto:${esc(operator.personalDataEmail)}">${esc(operator.personalDataEmail)}</a>` : 'Не указан';
const seller = () => {
  const registration = !isIndividualEntrepreneur || operator.publishRegistrationAddress === true
    ? `<p>Адрес регистрации: ${field('legalAddress')}.</p>` : '';
  const trade = esc(store.physicalStoreAddress || 'не указан');
  const regNumber = isIndividualEntrepreneur ? 'ОГРНИП' : 'ОГРН';
  return `<p>Продавец и оператор персональных данных: <strong>${name}</strong>. Организационно-правовая форма: ${field('legalForm')}. ИНН: ${field('inn')}; ${regNumber}: ${field('ogrn')}.</p>${registration}<p>Адрес торговой точки: ${trade}. Контактный телефон: ${field('contactPhone')}. Email по вопросам заказов: <a href="mailto:${esc(operator.businessEmail || '')}">${field('businessEmail')}</a>. Обращения по персональным данным: ${email()}.</p>`;
};
const pages = {
  seller: {
    title:'Сведения о продавце',
    intro:'Официальные реквизиты продавца, контактная информация и место получения заказов.',
    html: [
      heading('Продавец Aroma Residence') + seller() + '</section>',
      heading('Обращения и претензии') + `<p>По вопросам заказов и претензий обращайтесь по адресу <a href="mailto:${esc(operator.businessEmail || '')}">${field('businessEmail')}</a> или телефону ${field('contactPhone')}. При обращении укажите номер заказа, суть требования и адрес для направления ответа. Ответ предоставляется в письменной или электронной форме по адресу, указанному в обращении, с соблюдением сроков законодательства РФ.</p><p>Подробнее: <a href="/sale/">условия продажи</a>, <a href="/returns/">возврат и отказ</a>, <a href="/privacy/">персональные данные</a>.</p></section>`,
    ].join('')
  },
  privacy: {
    title:'Политика обработки персональных данных',
    intro:'Объясняем, какие данные получает магазин, для каких целей и как вы можете ими управлять.',
    html: [
      heading('Оператор и область применения') + seller() + '<p>Политика применяется к сайту Aroma Residence и заявкам покупателей. Действует в отношении данных посетителей и покупателей, предоставленных через формы магазина и полученных при его техническом обслуживании.</p></section>',
      heading('Категории данных и цели') + list([
        'Оформление и сопровождение заказа: имя, телефон, необязательный email, состав корзины, объём, количество, комментарий, адрес и способ доставки. Основание — выполнение договора/преддоговорных действий по инициативе покупателя (ст. 6 ч. 1 п. 5 закона №152-ФЗ), а для иных операций — согласие, когда оно необходимо.',
        'Защита сайта и предотвращение злоупотреблений: время обращения, IP-адрес, сведения об устройстве и технические журналы в минимально необходимом объёме. Основание определяется законной целью обработки и подтверждается внутренними документами оператора.',
        'Настройки корзины и интерфейса: технические сведения в локальном хранилище браузера для работы сайта.',
        'Необязательная аналитика и реклама: используются только после подключения конкретных сервисов, отдельной проверки передачи данных и выбора посетителя, если согласие требуется.'
      ]) + '</section>',
      heading('Обработка, хранение и передача') + `<p>Оператор ограничивает доступ к данным уполномоченными сотрудниками и исполнителями, использует технические и организационные меры безопасности, резервное копирование и контроль доступа. Данные обрабатываются в объёме, необходимом для соответствующих целей. Передача контрагентам возможна только при наличии законного основания и необходимых договорных и защитных мер.</p><p>При сборе персональных данных граждан РФ применяются требования локализации баз данных на территории Российской Федерации. Подтверждённый хостинг: <strong>${approved ? esc(processOptions.hostCompany) : 'не выбран'}</strong>. Трансграничные передачи ${approved ? (processOptions.crossBorderTransfers === 'none' ? 'не предусмотрены для описанного процесса' : 'допускаются только при соблюдении специальных требований закона и указанной в документах схеме') : 'требуют отдельной проверки'}.</p><p>Храним данные до выполнения соответствующей цели и в пределах предусмотренных законом сроков для обязательных документов; удаляем или обезличиваем, когда основания обработки прекращаются, если закон не требует иного.</p></section>`,
      heading('Права посетителя') + '<p>Вы можете запросить информацию об обработке, потребовать уточнения, блокирования или удаления данных в предусмотренных законом случаях, отозвать согласие, а также обратиться в Роскомнадзор или суд. Для обращения используйте контакт оператора: ' + email() + '.</p><p>Отзыв согласия не прекращает обработку данных, для которой сохраняется иное законное основание, например выполнение обязательств или требования закона.</p></section>',
      heading('Обновление документа') + `<p>Редакция: ${esc(stamp)}. Изменения публикуются на этой странице. Актуальная <a href="/cookies/">политика использования cookies</a> и <a href="/consent/">условия отдельного согласия</a> доступны в соответствующих разделах.</p></section>`,
    ].join('')
  },
  consent: {
    title:'Согласие на обработку персональных данных',
    intro:'Самостоятельный текст согласия для тех операций, где правовым основанием выступает согласие пользователя.',
    html: [
      heading('Кому предоставляется согласие') + seller() + '</section>',
      heading('Цели и перечень данных') + '<p>Цель: обработка обращения пользователя, подтверждение заказа, связь по заявке и согласование доставки, если для конкретной операции требуется согласие. Данные: имя, телефон, email (если указан), адрес доставки (если нужен), комментарий и состав заказа.</p><p>Действия: сбор, запись, систематизация, накопление, хранение, уточнение, использование, передача исполнителям по доставке в необходимом объёме, блокирование и удаление. Обработка может выполняться автоматизированными и неавтоматизированными способами.</p></section>',
      heading('Порядок предоставления и отзыва') + '<p>Согласие предоставляется самостоятельным действием — установкой непредустановленной отметки в форме с ссылкой на этот текст. Оно не включает рекламу, рассылки и публикацию данных. Согласие добровольно, действует до достижения указанной цели или отзыва, если закон не предусматривает иного основания и срока.</p><p>Для отзыва направьте обращение на ' + email() + '. Отзыв не затрагивает обязательства, для которых обработка допускается на ином основании по закону.</p></section>',
      heading('Прозрачность') + '<p>Подробная информация о правах, сроках, хранении, порядке запросов и контрагентах содержится в <a href="/privacy/">Политике обработки персональных данных</a>. Согласие на рекламу, если магазин введёт такую функцию, должно запрашиваться отдельно и не может быть условием оформления заказа.</p></section>',
    ].join('')
  },
  cookies: {
    title:'Cookies и локальное хранилище',
    intro:'Здесь описано, какие технологии используются для работы сайта, и как изменить настройки.',
    html: [
      heading('Что хранится в браузере') + '<p>Сайт может использовать необходимые cookie-файлы, localStorage и другие средства хранения состояния, чтобы сохранять корзину, настройки интерфейса и защиту авторизованной админки. Эти сведения не должны использоваться для рекламы без отдельного правового основания.</p></section>',
      heading('Категории') + list([
        '<strong>Необходимые.</strong> Корзина, безопасность и функциональность сайта. Необходимы для работы выбранных вами возможностей.',
        `<strong>Аналитические.</strong> ${processOptions.analyticsEnabled ? 'Включаются только после вашего выбора и с учётом настроек подключённых сервисов.' : 'Сейчас не подключены и не используются нашим модулем.'}`,
        `<strong>Маркетинговые.</strong> ${processOptions.marketingEnabled ? 'Включаются только после отдельного согласия и проверки провайдеров.' : 'Сейчас не подключены и не используются нашим модулем.'}`
      ]) + '</section>',
      heading('Встроенная карта') + '<p>Некоторые страницы магазина содержат карту Яндекса. При её загрузке браузер устанавливает соединение с соответствующим сторонним сервисом; он может обрабатывать IP-адрес и технические сведения по своим правилам. Продавец должен проверить состав такого обмена, порядок информирования и правовые основания ещё до запуска. Наш баннер не блокирует уже существующее встроенное содержимое автоматически.</p></section>',
      heading('Как управлять') + '<p>При первом посещении можно оставить только необходимые технологии. Позднее изменить решение можно через ссылку «Настройки cookies» внизу страницы. При запрете необязательных категорий сайт продолжает показывать каталог и корзину.</p><p>Также можно удалить данные сайта в настройках браузера. Это сбросит корзину и сохранённые предпочтения.</p><p><button type="button" data-ar-privacy-settings class="ar-legal-button ar-legal-button-outline">Открыть настройки cookies</button></p></section>',
      heading('Данные и контакты') + '<p>Обработка персональных данных, связанных с техническими идентификаторами, описана в <a href="/privacy/">Политике персональных данных</a>. Обращения по приватности: ' + email() + '.</p></section>'
    ].join('')
  },
  returns: {
    title:'Возврат и отказ от товара',
    intro:'Порядок обращений при дистанционной покупке парфюмерии.',
    html: [
      heading('Отказ до передачи') + '<p>Покупатель вправе отказаться от товара в любое время до его передачи. Сообщите о решении продавцу по контактам, указанным на сайте.</p></section>',
      heading('Возврат после передачи') + '<p>При дистанционной продаже покупатель, как правило, вправе отказаться от товара надлежащего качества в течение семи дней после передачи. Если информация о порядке и сроках возврата не была предоставлена в письменной форме при доставке, срок может составить три месяца. Условия возврата, сохранность товарного вида и потребительских свойств, а также особенности индивидуально-определённых товаров оцениваются по действующему законодательству; автоматического запрета возврата всей парфюмерии при дистанционной продаже нет.</p></section>',
      heading('Товар ненадлежащего качества') + '<p>При обнаружении недостатка применяются права потребителя, предусмотренные Законом РФ «О защите прав потребителей». Продавец не вправе ограничивать законные права покупателя положениями на сайте.</p></section>',
      heading('Как обратиться') + seller() + '<p>Укажите номер заказа, суть обращения и удобный контакт. Возврат денежных средств и расходы производятся по правилам законодательства РФ с учётом обстоятельств заказа.</p></section>',
    ].join('')
  },
  sale: {
    title:'Условия продажи и оформления заказа',
    intro:'Важная информация о продавце, подтверждении наличия, доставке и оплате.',
    html: [
      heading('Продавец') + seller() + '</section>',
      heading('Как оформить') + '<p>Покупатель выбирает аромат, объём и количество, формирует корзину и направляет заказ. Продавец связывается для уточнения наличия, конечной стоимости и условий передачи. Сайт не осуществляет приём платежей, пока отдельно не подключена законная платёжная инфраструктура. Момент заключения договора и обязательства сторон определяются законодательством о дистанционной продаже, а не произвольным текстом сайта.</p></section>',
      heading('Цена, доставка и оплата') + '<p>Указанные на сайте цены относятся к выбранному объёму; окончательные условия доставки до адреса или пункта выдачи согласовываются до расчёта. Варианты доставки представлены в разделе <a href="/dostavka/">«Доставка»</a>. Приём оплаты осуществляется продавцом законным способом с применением ККТ и выдачей чека в случаях, предусмотренных №54-ФЗ. Не отправляйте данные банковской карты в комментариях к заказу.</p></section>',
      heading('Возврат и персональные данные') + '<p>Условия возврата описаны в разделе <a href="/returns/">«Возврат и отказ от товара»</a>. При оформлении обращения данные обрабатываются в соответствии с <a href="/privacy/">Политикой обработки персональных данных</a> и действующим законодательством.</p></section>',
    ].join('')
  }
};

function documentPage(key, page) {
  const canonical = approved ? `<link rel="canonical" href="${esc(cfg.siteUrl.replace(/\/$/,'') + '/' + key + '/')}">` : '';
  const robots = draft ? 'noindex,nofollow' : 'index,follow';
  const footer = `<footer class="ar-legal-doc-footer"><a href="/">Главная</a><a href="/privacy/">Персональные данные</a><a href="/consent/">Согласие</a><a href="/cookies/">Cookies</a><a href="/returns/">Возврат</a><a href="/sale/">Условия продажи</a><a href="/seller/">Продавец</a><button type="button" data-ar-privacy-settings class="ar-legal-button ar-legal-button-outline">Настройки cookies</button></footer>`;
  return `<!doctype html><html lang="ru" data-ar-analytics-enabled="${processOptions.analyticsEnabled === true}" data-ar-marketing-enabled="${processOptions.marketingEnabled === true}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="${robots}"><meta name="description" content="${esc(page.intro)}"><meta name="theme-color" content="#0D4C3C"><title>${esc(page.title)} — Aroma Residence</title>${canonical}<link rel="stylesheet" href="/assets/legal-compliance.css"><link rel="stylesheet" href="/assets/typography.css"><script src="/assets/legal-compliance.js" defer></script></head><body class="ar-legal-document"><header class="ar-legal-doc-header"><a class="ar-legal-doc-brand" href="/">AROMA RESIDENCE</a><a class="ar-legal-doc-home" href="/">Вернуться в бутик</a></header><main id="main" class="ar-legal-doc-inner"><span class="ar-legal-doc-eyebrow">ATELIER DE PARFUM · ИНФОРМАЦИЯ</span><h1>${esc(page.title)}</h1><p class="ar-legal-doc-subtitle">${esc(page.intro)}</p>${draftWarning}${page.html}<p class="ar-legal-doc-subtitle">Редакция документа: ${esc(stamp)}.</p></main>${footer}</body></html>`;
}
const linkMarkup = '<nav class="ar-legal-inline-links" aria-label="Правовая информация"><a href="/privacy/">Персональные данные</a><a href="/consent/">Согласие</a><a href="/cookies/">Cookies</a><a href="/sale/">Условия продажи</a><a href="/returns/">Возврат</a><a href="/seller/">Продавец</a><button type="button" data-ar-privacy-settings>Настройки cookies</button></nav>';
const cssTag = '<link rel="stylesheet" href="/assets/legal-compliance.css" data-ar-legal-bundle="1">';
const jsTag = '<script src="/assets/legal-compliance.js" defer data-ar-legal-bundle="1"></script>';
const consentLabel = '<span>Согласен(на) на обработку контактных данных для оформления и сопровождения заявки. <a href="/consent/" target="_blank" rel="noopener noreferrer">Текст согласия</a> · <a href="/privacy/" target="_blank" rel="noopener noreferrer">Политика персональных данных</a>.</span>';
function walkHtml(dir) {
  const result=[];
  for (const dirent of fs.readdirSync(dir, {withFileTypes:true})) {
    if (dirent.isDirectory()) {
      if (!['node_modules','.git'].includes(dirent.name) && !fs.statSync(path.join(dir,dirent.name)).isSymbolicLink()) result.push(...walkHtml(path.join(dir,dirent.name)));
    } else if (dirent.isFile() && dirent.name.endsWith('.html')) result.push(path.join(dir,dirent.name));
  }
  return result;
}
const report = {dryRun,production,approved,missing,patched:[],skipped:[],added:[]};
for (const htmlFile of walkHtml(root)) {
  const relative = path.relative(root,htmlFile).replace(/\\/g,'/');
  if (/^(?:privacy|cookies|consent|returns|sale|seller)\//.test(relative)) continue;
  let html = fs.readFileSync(htmlFile,'utf8');
  if (!/aroma residence|резиденция ароматов/i.test(html) || !/<\/body>/i.test(html)) {
    report.skipped.push(relative); continue;
  }
  let changed = false;
  if (/<html\b/i.test(html) && !/\bdata-ar-analytics-enabled\s*=/i.test(html)) {
    html = html.replace(/<html\b/i, `<html data-ar-analytics-enabled="${processOptions.analyticsEnabled === true}" data-ar-marketing-enabled="${processOptions.marketingEnabled === true}"`);
    changed = true;
  }
  if (!html.includes('data-ar-legal-bundle="1"')) {
    html=html.replace(/<\/head>/i, `${cssTag}\n</head>`);
    html=html.replace(/<\/body>/i, `${jsTag}\n</body>`);
    changed=true;
  }
  if (!html.includes('aria-label="Правовая информация"')) {
    if (/<\/footer>/i.test(html)) html=html.replace(/<\/footer>/i, `${linkMarkup}\n</footer>`);
    else html=html.replace(/<\/body>/i, `${linkMarkup}\n</body>`);
    changed=true;
  }
  // Keep the map's footprint and navigation, but do not contact Yandex until an explicit click.
  // The iframe URL is preserved verbatim in data-ar-map-src and is restored by the additive JS.
  if (/<iframe\b[^>]*(?<![\w-])src=[\"']https:\/\/yandex\.ru\/map-widget\//i.test(html)) {
    const prior = html;
    html = html.replace(/<iframe\b[^>]*>/gi, (tag) => {
      if (!/(?<![\w-])src=[\"']https:\/\/yandex\.ru\/map-widget\//i.test(tag)) return tag;
      return tag.replace(/(?<![\w-])src\s*=/i, 'data-ar-map-src=')
        .replace(/<iframe\b/i, '<iframe data-ar-map-optin=\"1\"');
    });
    changed ||= prior !== html;
  }
  if (/^admin\/index\.html$/.test(relative) && !html.includes('data-ar-orders-bundle=\"1\"')) {
    html = html.replace(/<\/head>/i, '<link rel=\"stylesheet\" href=\"/assets/admin-orders.css\" data-ar-orders-bundle=\"1\">\n</head>');
    html = html.replace(/<\/body>/i, '<script src=\"/assets/admin-orders.js\" defer data-ar-orders-bundle=\"1\"></script>\n</body>');
    if (!html.includes('data-ar-editor-bundle="1"')) {
      html = html.replace(/<\/head>/i, '<link rel="stylesheet" href="/assets/admin-editor.css" data-ar-editor-bundle="1">\n</head>');
      html = html.replace(/<\/body>/i, '<script src="/assets/admin-editor.js" defer data-ar-editor-bundle="1"></script>\n</body>');
    }
    changed = true;
  }
  if (/cart\/index\.html$/.test(relative)) {
    const prior = html;
    html=html.replace(/<span>Согласен\(на\) на обработку указанных контактных данных для ответа на заявку\.<\/span>/i, consentLabel);
    changed ||= prior !== html;
  }
  if (changed) {
    if (!dryRun) fs.writeFileSync(htmlFile,html,'utf8');
    report.patched.push(relative);
  }
}
const sourceAssets = path.join(__dirname,'assets');
const destAssets = path.join(root,'assets');
if (!dryRun) fs.mkdirSync(destAssets,{recursive:true});
for(const asset of ['legal-compliance.css','legal-compliance.js','admin-orders.css','admin-orders.js','admin-editor.css','admin-editor.js','dynamic-product.css','dynamic-product.js']) {
  if(!dryRun) fs.copyFileSync(path.join(sourceAssets,asset),path.join(destAssets,asset));
  report.added.push(`assets/${asset}`);
}
for (const [key,page] of Object.entries(pages)) {
  if(!dryRun){
    fs.mkdirSync(path.join(root,key),{recursive:true});
    fs.writeFileSync(path.join(root,key,'index.html'),documentPage(key,page),'utf8');
  }
  report.added.push(`${key}/index.html`);
}
const sitemap=path.join(root,'sitemap.xml');
if (approved && fs.existsSync(sitemap)) {
  let xml=fs.readFileSync(sitemap,'utf8');
  const base=cfg.siteUrl.replace(/\/$/,'');
  for (const key of Object.keys(pages)) {
    const url=`${base}/${key}/`;
    if(!xml.includes(`<loc>${url}</loc>`)) xml=xml.replace('</urlset>',`<url><loc>${url}</loc></url>\n</urlset>`);
  }
  if(!dryRun) fs.writeFileSync(sitemap,xml,'utf8');
  report.added.push('sitemap.xml entries');
}
report.checksum=crypto.createHash('sha256').update(JSON.stringify({cfg,report})).digest('hex');
if(!dryRun) fs.writeFileSync(path.join(root,'compliance-patch-manifest.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
if(draft)console.error('NOTICE: юридические страницы остаются ЧЕРНОВИКАМИ. Production заблокирован до подтверждения оператора и требований РФ.');
