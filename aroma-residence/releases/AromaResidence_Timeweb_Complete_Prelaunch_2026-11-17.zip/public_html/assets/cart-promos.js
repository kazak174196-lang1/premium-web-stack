'use strict';
(()=>{
const input=document.getElementById('ar-promo-input'),button=document.getElementById('ar-promo-apply'),status=document.getElementById('ar-promo-status');
if(!input||!button||!status)return;
const money=n=>new Intl.NumberFormat('ru-RU').format(n)+' ₽';
input.disabled=true;button.disabled=true;status.textContent='Проверяем доступность промокодов…';
fetch('/api/promo-status',{cache:'no-store'}).then(async response=>{if(!response.ok)throw Error('Недоступно');return response.json()}).then(data=>{if(data.available===true){input.disabled=false;button.disabled=false;status.textContent='Введите промокод. На парфюмерные сеты промокоды не распространяются.'}else{status.textContent='Промокоды активируются после подключения базы и защищённой админки.'}}).catch(()=>{status.textContent='Сервис промокодов пока недоступен.'});
input.addEventListener('input',()=>{if(window.aromaPromo&&input.value.trim().toUpperCase()!==window.aromaPromo.code)status.textContent='Код изменён. Нажмите «Применить», чтобы проверить новую скидку.'});
button.addEventListener('click',async()=>{
 const code=input.value.trim().toUpperCase();
 if(!/^[A-Z0-9][A-Z0-9_-]{2,23}$/.test(code)){status.textContent='Укажите промокод длиной от 3 до 24 символов.';return}
 const cart=window.aromaCartSnapshot?.();
 if(!Array.isArray(cart)||!cart.length){status.textContent='Сначала добавьте товары.';return}
 if(!cart.some(item=>!item.setId)){status.textContent='Промокод можно применить к отдельным ароматам. На сеты уже действует скидка.';return}
 button.disabled=true;status.textContent='Проверяем промокод…';
 try{
  const response=await fetch('/api/quote',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({items:cart,promoCode:code})});
  const result=await response.json().catch(()=>({error:'Некорректный ответ сервера.'}));
  if(!response.ok)throw Error(result.error||'Промокод недоступен.');
  if(result.promo?.code!==code||!Number.isSafeInteger(result.promoDiscount)||result.promoDiscount<=0)throw Error('Скидка не подтверждена.');
  if(result.subtotal!==window.aromaBaseAmount?.()||result.setDiscount!==window.aromaSetAmount?.())throw Error('Цены были обновлены. Обновите страницу перед применением кода.');
  window.aromaPromo={code,percent:result.promo.percent,discount:result.promoDiscount};
  window.aromaRecalculate?.();
  status.textContent='Код '+code+' применён. Скидка '+result.promo.percent+'% (−'+money(result.promoDiscount)+') на отдельные ароматы.';
 }catch(err){window.aromaPromo=null;window.aromaRecalculate?.();status.textContent=err.message||'Не удалось проверить промокод.'}
 finally{button.disabled=false}
});
window.addEventListener('aroma-cart-updated',()=>{if(!window.aromaPromo)status.textContent='Состав заказа изменился. При необходимости примените промокод повторно.'});
})();
