'use strict';
(()=>{
const STORE='aroma-residence-cart-v1';
const $=s=>document.querySelector(s);
const money=n=>new Intl.NumberFormat('ru-RU').format(n)+' ₽';
const safeQty=x=>Number.isInteger(x)&&x>=1&&x<=30;
let listingPromise;
const productList=()=>{
 if(!listingPromise){
 listingPromise=(async()=>{
  for(const url of ['/api/catalog','/assets/catalog-data.json']){
   try{
    const res=await fetch(url,{cache:'no-store'});
    if(!res.ok)continue;
    const data=await res.json();
    const list=Array.isArray(data)?data:data?.products;
    if(Array.isArray(list)&&list.length)return list.filter(p=>typeof p.id==='string'&&p.prices&&typeof p.prices==='object');
   }catch{}
  }
  throw new Error(navigator.onLine===false?'Нет подключения к интернету. Корзина сохранена в этом браузере.':'Не удалось загрузить каталог. Обновите страницу и попробуйте ещё раз.');
 })();
 listingPromise.catch(()=>{listingPromise=undefined});
 }
 return listingPromise;
};
const clean=(data)=>{
 const cart=[];if(!Array.isArray(data))return cart;
 for(const raw of data.slice(0,120)){
  if(!raw||typeof raw.id!=='string'||!Number.isFinite(Number(raw.ml))||!safeQty(raw.qty))continue;
  const ml=String(raw.ml);if(!/^[1-9]\d?$/.test(ml))continue;
  const setId=typeof raw.setId==='string'&&/^[a-zA-Z0-9-]{8,64}$/.test(raw.setId)?raw.setId:null;
  if(raw.setId!==undefined&&!setId)continue;
  if(setId&&raw.qty!==1)continue;
  const match=cart.find(x=>x.id===raw.id&&x.ml===ml&&(x.setId||null)===setId);
  if(match){if(!setId)match.qty=Math.min(30,match.qty+raw.qty)}
  else if(cart.length<80)cart.push(setId?{id:raw.id,ml,qty:1,setId}:{id:raw.id,ml,qty:raw.qty});
 }
 return cart;
};
const read=()=>{try{return clean(JSON.parse(localStorage.getItem(STORE)||'[]'))}catch{return[]}};
const save=cart=>{
 try{localStorage.setItem(STORE,JSON.stringify(clean(cart)));window.aromaPromo=null;return true}catch{return false}
};
const count=cart=>cart.reduce((n,x)=>n+x.qty,0);
const refresh=()=>{
 const n=count(read());
 document.querySelectorAll('[data-ar-cart-counter],[data-ar-menu-count],#ar-cart-counter').forEach(el=>el.textContent=String(n));
 document.querySelectorAll('.ar-header-bag').forEach(el=>el.setAttribute('aria-label','Корзина: '+n+' товаров'));
};
const emit=()=>{refresh();window.dispatchEvent(new Event('aroma-cart-change'));window.dispatchEvent(new Event('aroma-cart-updated'))};
const valid=(p,ml)=>p&&Object.prototype.hasOwnProperty.call(p.prices,String(ml))&&Number.isFinite(Number(p.prices[String(ml)]))&&Number(p.prices[String(ml)])>0;
const add=async(id,ml)=>{
 const data=await productList();
 const item=data.find(p=>p.id===id);
 if(!valid(item,ml))throw new Error('Выбранный объём сейчас недоступен.');
 const cart=read();const selected=String(ml),current=cart.find(x=>x.id===id&&x.ml===selected&&!x.setId);
 if(current){
  if(current.qty>=30)throw new Error('Для одного объёма можно добавить не более 30 флаконов.');
  current.qty++;
 }else{if(cart.length>=80)throw new Error('В корзине достигнут лимит позиций.');cart.push({id,ml:selected,qty:1})}
 if(!save(cart))throw new Error('Не удалось сохранить корзину. Разрешите хранение данных в браузере.');
 emit();
 return {item,ml:selected,price:Number(item.prices[selected])};
};
let toastTimer;
const toast=(title,secondary)=>{
 let box=$('#ar-cart-toast');
 if(!box){box=document.createElement('div');box.id='ar-cart-toast';box.className='ar-cart-toast';box.setAttribute('role','status');box.setAttribute('aria-live','polite');document.body.append(box)}
 box.replaceChildren();
 const content=document.createElement('div');content.className='ar-toast-copy';
 const heading=document.createElement('strong');heading.textContent=title;
 const message=document.createElement('span');message.textContent=secondary||'';
 content.append(heading,message);
 const link=document.createElement('a');link.href='/cart/';link.textContent='В корзину ↗';
 const close=document.createElement('button');close.type='button';close.setAttribute('aria-label','Закрыть уведомление');close.textContent='×';close.addEventListener('click',()=>box.classList.remove('is-visible'));
 box.append(content,link,close);box.classList.add('is-visible');
 clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.classList.remove('is-visible'),5000);
};
const chosenMl=button=>{
 const card=button.closest('.product-card');
 const modal=button.closest('#product-modal');
 const detail=button.closest('[data-product-page]');
 const scope=card||modal||detail;
 const active=scope?.querySelector('[data-card-size].active,[data-modal-size].active,[data-page-size].active');
 const raw=active?.dataset.cardSize||active?.dataset.modalSize||active?.dataset.pageSize;
 return raw&&/^[1-9]\d?$/.test(raw)?raw:null;
};
document.addEventListener('click',async event=>{
 const btn=event.target instanceof Element?event.target.closest('[data-cart-add]'):null;
 if(!btn)return;
 event.preventDefault();
 if(btn.disabled)return;
 const id=btn.getAttribute('data-cart-add'),ml=chosenMl(btn);
 if(!id||!ml){toast('Выберите объём','Нажмите нужный вариант миллилитров над кнопкой.');return}
 btn.disabled=true;btn.setAttribute('aria-busy','true');
 try{const result=await add(id,ml);toast('Добавлено в корзину',result.item.name+' · '+result.ml+' мл · '+money(result.price))}
 catch(err){toast('Не удалось добавить аромат',err.message||'Попробуйте повторить действие.')}
 finally{btn.disabled=false;btn.removeAttribute('aria-busy')}
});
window.addEventListener('storage',()=>{window.aromaPromo=null;refresh();if($('#ar-order-items'))renderOrder()});
window.addEventListener('pageshow',refresh);
refresh();
const form=$('#ar-order-form');
if(!form)return;
const region=$('#ar-order-items'),empty=$('#ar-order-empty'),total=$('#ar-order-total'),counter=$('#ar-order-count'),send=$('#ar-send-order'),copy=$('#ar-copy-order'),status=$('#ar-order-status');
copy.disabled=true;
let catalog=[],known=new Map(),renderError=null,checkoutBusy=false,emailEnabled=false;
const amount=entry=>Number(known.get(entry.id)?.prices?.[entry.ml]||0)*entry.qty;
const subtotalPrice=cart=>cart.reduce((sum,item)=>sum+amount(item),0);
const groupEntries=cart=>{const grouped=new Map();for(const entry of cart)if(entry.setId){const list=grouped.get(entry.setId)||[];list.push(entry);grouped.set(entry.setId,list)}return grouped};
const validGroup=rows=>[3,5].includes(rows.length)&&new Set(rows.map(x=>x.id)).size===rows.length&&rows.every(x=>x.qty===1&&valid(known.get(x.id),x.ml));
const setDiscountFor=cart=>{let sum=0;for(const rows of groupEntries(cart).values())if(validGroup(rows))sum+=Math.round(subtotalPrice(rows)*(rows.length===3?5:10)/100);return sum};
const totalPrice=cart=>subtotalPrice(cart)-setDiscountFor(cart)-(window.aromaPromo?.discount||0);
const node=(tag,cls,text)=>{
 const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;
};
function itemRow(entry){
 const item=known.get(entry.id),row=node('article','ar-line-item');
 const photo=node('a','ar-line-photo');photo.href='/catalog/'+encodeURIComponent(entry.id)+'/';
 const img=node('img');img.alt=item.name;img.src=item.image||'/assets/emerald-hero.webp';img.loading='lazy';img.decoding='async';img.width=82;img.height=105;photo.append(img);
 const info=node('div','ar-line-info');
 const brand=node('span','ar-line-brand',item.brand);
 const title=node('a','ar-line-name',item.title||item.name);title.href='/catalog/'+encodeURIComponent(entry.id)+'/';
 const volume=node('label','ar-line-volume-editor');const caption=node('span','','Объём распива');const picker=node('select','ar-volume-select');picker.setAttribute('aria-label','Выбрать объём '+item.name);picker.dataset.itemId=entry.id;for(const [ml,val] of Object.entries(item.prices||{}).filter(([ml,val])=>Number(ml)>0&&Number(val)>0).sort(([a],[b])=>Number(a)-Number(b)))picker.add(new Option(ml+' мл · '+money(Number(val)),ml));picker.value=entry.ml;picker.addEventListener('change',()=>changeVolume(entry.id,entry.ml,picker.value));volume.append(caption,picker);
 const buttons=node('div','ar-line-stepper');
 const minus=node('button','ar-stepper-btn','−');minus.type='button';minus.setAttribute('aria-label','Уменьшить количество '+item.name);
 const num=node('span','ar-line-qty',String(entry.qty));num.setAttribute('aria-live','polite');
 const plus=node('button','ar-stepper-btn','+');plus.type='button';plus.setAttribute('aria-label','Увеличить количество '+item.name);
 plus.disabled=entry.qty>=30;
 minus.addEventListener('click',()=>modify(entry.id,entry.ml,entry.qty-1));
 plus.addEventListener('click',()=>modify(entry.id,entry.ml,entry.qty+1));
 buttons.append(minus,num,plus);info.append(brand,title,volume,buttons);
 const aside=node('div','ar-line-trailing');
 const price=node('strong','ar-line-price',money(amount(entry)));
 const remove=node('button','ar-line-remove','Убрать');remove.type='button';remove.setAttribute('aria-label','Удалить '+item.name+' из корзины');remove.addEventListener('click',()=>modify(entry.id,entry.ml,0));
 aside.append(price,remove);
 row.append(photo,info,aside);return row;
}
function changeVolume(id,from,to){if(checkoutBusy||from===to)return;const product=known.get(id);if(!valid(product,to)){status.textContent='Выбранный объём недоступен.';renderOrder();return}let cart=read();const source=cart.find(x=>x.id===id&&x.ml===from);if(!source){renderOrder();return}const dest=cart.find(x=>x.id===id&&x.ml===to&&(x.setId||null)===(source.setId||null));if(dest){if(dest.qty+source.qty>30){status.textContent='Для одного объёма можно выбрать не более 30 штук.';renderOrder();return}dest.qty+=source.qty;cart=cart.filter(x=>x!==source)}else source.ml=to;if(!save(cart)){status.textContent='Не удалось сохранить объём. Проверьте настройки браузера.';renderOrder();return}emit();renderOrder();status.textContent='Объём изменён, сумма пересчитана.';const chosen=[...region.querySelectorAll('.ar-volume-select')].find(x=>x.dataset.itemId===id&&x.value===to);chosen?.focus({preventScroll:true});}
function modify(id,ml,qty){
 if(checkoutBusy)return;
 let cart=read();
 if(qty<=0)cart=cart.filter(e=>!(e.id===id&&e.ml===ml&&!e.setId));
 else if(safeQty(qty))cart=cart.map(e=>e.id===id&&e.ml===ml&&!e.setId?{...e,qty}:e);
 else return;
 if(!save(cart)){status.textContent='Не удалось сохранить изменения. Проверьте настройки браузера.';return}
 emit();renderOrder();
}
function renderOrder(){
 const cart=read(),ready=!!catalog.length;
 region.replaceChildren();renderError=null;
 if(!ready){region.append(node('p','ar-cart-loading','Не удалось загрузить каталог. Корзина сохранена в этом браузере.'));send.disabled=true;copy.disabled=true;return}
 const available=cart.filter(e=>valid(known.get(e.id),e.ml));
 const invalidGroups=[...groupEntries(cart).values()].filter(rows=>!validGroup(rows));
 const invalid=cart.filter(e=>!valid(known.get(e.id),e.ml));
 if(invalid.length){
  const warn=node('p','ar-order-warning','Некоторые позиции больше недоступны. Удалите их из корзины, чтобы отправить заявку.');
  region.append(warn);
  for(const bad of invalid){
   const entry=node('div','ar-invalid-entry');
   entry.append(node('span','',bad.id+' · '+bad.ml+' мл — недоступно'));
   const remove=node('button','','Убрать');remove.type='button';remove.addEventListener('click',()=>modify(bad.id,bad.ml,0));entry.append(remove);region.append(entry);
  }
 }
 if(!cart.length){empty.hidden=false;counter.textContent='0 ароматов';send.disabled=true;copy.disabled=true;total.textContent='0 ₽';return}
 empty.hidden=true;
 for(const entries of groupEntries(available).values()){
  const wrapper=document.createElement('section');wrapper.className='ar-set-group';
  const heading=node('div','ar-set-group-heading');
  const copy=node('div','ar-set-group-label');
  copy.append(node('span','ar-set-overline','PARFUM COLLECTION'));
  copy.append(node('h3','','Парфюмерный сет из '+entries.length+' ароматов'));
  const savings=Math.round(subtotalPrice(entries)*(entries.length===3?5:10)/100);
  copy.append(node('span','ar-set-savings','Скидка '+(entries.length===3?5:10)+'% · экономия '+money(savings)));
  const remove=node('button','ar-set-delete','Удалить сет');remove.type='button';remove.addEventListener('click',()=>{
   if(checkoutBusy)return;
   if(!save(read().filter(x=>x.setId!==entries[0].setId))){status.textContent='Не удалось изменить корзину.';return}
   emit();renderOrder();
  });
  heading.append(copy,remove);wrapper.append(heading);
  for(const entry of entries){
   const row=itemRow(entry);row.classList.add('ar-set-member');
   row.querySelector('.ar-line-stepper')?.remove();
   row.querySelector('.ar-line-remove')?.remove();
   wrapper.append(row);
  }
  wrapper.append(node('p','ar-set-group-total','Стоимость сета со скидкой: '+money(subtotalPrice(entries)-savings)));
  region.append(wrapper);
 }
 available.filter(x=>!x.setId).forEach(entry=>region.append(itemRow(entry)));
 if(invalidGroups.length)region.prepend(node('p','ar-order-warning','Нарушен состав сета. Удалите его и соберите набор заново.'));
 counter.textContent=count(available)+' шт. · '+available.length+' позиций';
 total.textContent=money(totalPrice(available));
 const original=document.getElementById('ar-subtotal');if(original)original.textContent=money(subtotalPrice(available));
 const savings=document.getElementById('ar-set-saving');if(savings)savings.textContent='−'+money(setDiscountFor(available));
 const extra=document.getElementById('ar-promo-saving');if(extra)extra.textContent='−'+money(window.aromaPromo?.discount||0);
 send.disabled=checkoutBusy||!emailEnabled||invalid.length>0||invalidGroups.length>0||!available.length;
copy.disabled=invalid.length>0||invalidGroups.length>0||!available.length;
}
window.aromaRecalculate=renderOrder;window.aromaCartSnapshot=read;window.aromaBaseAmount=()=>subtotalPrice(read());window.aromaSetAmount=()=>setDiscountFor(read());
const orderText=()=>{
 const cart=read().filter(e=>valid(known.get(e.id),e.ml)),data=new FormData(form);
 const lines=[];const seen=new Set();
 for(const entry of cart){
  if(entry.setId){
   if(seen.has(entry.setId))continue;
   seen.add(entry.setId);const members=cart.filter(x=>x.setId===entry.setId),discount=Math.round(subtotalPrice(members)*(members.length===3?5:10)/100);
   lines.push('ПАРФЮМЕРНЫЙ СЕТ: '+members.length+' аромата (−'+(members.length===3?5:10)+'%)');
   for(const row of members){const p=known.get(row.id);lines.push('  '+p.name+' — '+row.ml+' мл = '+money(amount(row)))}
   lines.push('  Скидка: −'+money(discount));
  }else{const p=known.get(entry.id);lines.push(p.name+' — '+entry.ml+' мл × '+entry.qty+' = '+money(amount(entry)))}
 }
 if(window.aromaPromo)lines.push('Промокод '+window.aromaPromo.code+': −'+money(window.aromaPromo.discount));const a=window.aromaDeliveryDetails?.();const address=a?.type==='pickup'?'Самовывоз — Челябинск':a?[a.city,a.region,a.postalCode,a.service==='pvz'?'ПВЗ: '+a.pickupPoint:'',a.street,a.house,a.apartment].filter(Boolean).join(', '):'Не указан';const carrier=a?.carrierLabel||'Не выбрана';return ['Заявка — Резиденция Ароматов','',...lines,'','Итого с учётом скидок на сеты: '+money(totalPrice(cart)),'Доставка: по согласованию','','Имя: '+data.get('name'),'Телефон: '+data.get('phone'),'Email: '+data.get('email'),'Получение: '+data.get('delivery'),'Служба: '+carrier,'Адрес: '+address,'Комментарий: '+(data.get('comment')||'')].join('\n');
};
copy.addEventListener('click',async()=>{
 if(!read().length){status.textContent='Сначала добавьте аромат в корзину.';return}
 try{
  await navigator.clipboard.writeText(orderText());status.textContent='Состав заказа скопирован. Вставьте его в сообщения магазина ВКонтакте.';
 }catch{status.textContent='Не удалось скопировать заказ. Разрешите доступ к буферу обмена.'}
});
form.addEventListener('submit',async e=>{
 e.preventDefault();if(checkoutBusy||!form.reportValidity())return;
 const cart=read(),bad=cart.filter(entry=>!valid(known.get(entry.id),entry.ml));
 if(!cart.length||bad.length){status.textContent='Проверьте состав заказа.';return}
 checkoutBusy=true;send.disabled=true;send.textContent='Отправляем заявку…';status.textContent='';
 const data=new FormData(form);
 try{
  const response=await fetch('/api/orders',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:data.get('name'),phone:data.get('phone'),email:data.get('email'),delivery:data.get('delivery'),comment:data.get('comment'),consent:data.get('consent')==='on',address:window.aromaDeliveryDetails?.(),items:cart,promoCode:window.aromaPromo?.code||''})});
  const result=await response.json().catch(()=>({error:'Сервер вернул некорректный ответ.'}));
  if(!response.ok)throw new Error(result.error||'Не удалось отправить заявку. Попробуйте позднее.');
  if(!result.orderId)throw new Error('Сервер не подтвердил сохранение заявки.');
  status.textContent='Заявка № '+result.orderId+' сохранена. '+(result.warning||'Магазин свяжется с вами для подтверждения.');
  if(!save([]))throw new Error('Заявка сохранена, но не удалось очистить корзину браузера.');
  emit();renderOrder();form.reset();
 }catch(err){
  status.textContent=(err.message||'Не удалось отправить заявку.')+' Вы можете скопировать заказ и отправить его в ВКонтакте.';
 }finally{checkoutBusy=false;send.textContent='Отправить заявку';renderOrder()}
});
fetch('/api/checkout-status',{cache:'no-store'}).then(async response=>{if(!response.ok)throw new Error('Unavailable');return response.json()}).then(data=>{emailEnabled=data?.emailOrdersAvailable===true;const el=$('#ar-email-status');if(el){el.textContent=emailEnabled?'Заявки принимаются. После отправки магазин подтвердит наличие и доставку.':'Отправка заявок на email пока не подключена. Скопируйте заказ и отправьте его в сообщения магазина ВКонтакте.';el.dataset.available=String(emailEnabled)}renderOrder()}).catch(()=>{emailEnabled=false;const el=$('#ar-email-status');if(el)el.textContent='Онлайн-отправка временно недоступна. Можно скопировать заказ и связаться с магазином.';renderOrder()});
productList().then(data=>{
 catalog=data;known=new Map(catalog.map(p=>[p.id,p]));renderOrder();
}).catch(err=>{
 region.replaceChildren(node('p','ar-cart-loading',err.message));copy.disabled=true;
 const retry=node('button','ar-order-retry','Повторить загрузку');retry.type='button';retry.onclick=()=>location.reload();region.append(retry);send.disabled=true;status.textContent='Корзина сохранена. При восстановлении соединения можно продолжить.';
});
})();
