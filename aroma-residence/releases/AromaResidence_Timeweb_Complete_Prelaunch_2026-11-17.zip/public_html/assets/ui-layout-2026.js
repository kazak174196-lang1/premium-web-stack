'use strict';(()=>{
const grid=document.getElementById('set-grid');
if(grid){const refresh=()=>{const cards=[...grid.children].filter(c=>c.classList?.contains('set-item'));grid.classList.toggle('ar-set-5',cards.length===5)};refresh();new MutationObserver(refresh).observe(grid,{childList:true})}
const align=root=>{for(const b of root.querySelectorAll?.('.ar-add-card')||[]){const card=b.closest('article,.product-card,.catalog-card,.perfume-card');if(!card||card.classList.contains('ar-align-product-card'))continue;card.classList.add('ar-align-product-card');const p=b.parentElement;if(p&&p!==card&&card.contains(p))p.classList.add('ar-align-product-actions')}};
align(document);const root=document.querySelector('#catalog,#catalog-grid,.catalog-grid,.products-grid,main');if(root){let pending=false;new MutationObserver(()=>{if(pending)return;pending=true;queueMicrotask(()=>{pending=false;align(root)})}).observe(root,{childList:true,subtree:true})}
})();