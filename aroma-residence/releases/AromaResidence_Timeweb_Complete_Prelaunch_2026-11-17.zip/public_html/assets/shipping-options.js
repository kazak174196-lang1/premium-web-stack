'use strict';(()=>{
const form=document.getElementById('ar-order-form'),widget=document.getElementById('ship-widget');
if(!form||!widget)return;
const delivery=form.elements.namedItem('delivery'),carriers=[...form.querySelectorAll('input[name="carrier"]')],services=[...form.querySelectorAll('input[name="service"]')];
const modeBox=document.getElementById('ship-modes'),address=document.getElementById('ship-address'),city=document.getElementById('ship-city'),courier=document.getElementById('ship-courier'),pvz=document.getElementById('ship-pvz'),notice=document.getElementById('ship-notice');
const names={yandex:'Яндекс Доставка',cdek:'СДЭК',fivepost:'5Post',russian_post:'Почта России',ozon:'Ozon Доставка'};
const modes={yandex:['pvz','courier'],cdek:['pvz','courier'],fivepost:['pvz'],russian_post:['pvz','courier'],ozon:['pvz','courier']};
const active=name=>form.querySelector('input[name="'+name+'"]:checked');
const reset=fields=>fields.forEach(field=>{field.checked=false;field.disabled=true});
const toggle=(node,enabled,required=[])=>{node.hidden=!enabled;node.querySelectorAll('input:not([type=radio])').forEach(el=>{el.disabled=!enabled;el.required=enabled&&required.includes(el.name)})};
function sync(){
 const kind=delivery.value;
 if(kind==='pickup'){widget.hidden=true;reset(carriers);reset(services);modeBox.hidden=true;address.hidden=true;toggle(city,false);toggle(courier,false);toggle(pvz,false);return}
 widget.hidden=false;const local=kind==='courier';
 for(const input of carriers){input.disabled=local&&!['yandex','cdek','ozon'].includes(input.value);if(input.disabled)input.checked=false;input.closest('label')?.classList.toggle('ship-disabled',input.disabled)}
 for(const radio of carriers)radio.required=!radio.disabled;
 const selected=active('carrier')?.value;
 modeBox.hidden=!selected||local;
 for(const input of services){input.disabled=!selected||local||!modes[selected]?.includes(input.value);if(input.disabled)input.checked=false;input.closest('label')?.classList.toggle('ship-disabled',input.disabled)}
 if(local&&selected){const check=services.find(x=>x.value==='courier');check.checked=true;check.disabled=false}
 else if(selected&&modes[selected].length===1){const check=services.find(x=>x.value===modes[selected][0]);check.checked=true;check.disabled=false}
 for(const radio of services)radio.required=!!selected&&!local&&!radio.disabled;
 const method=active('service')?.value;
 address.hidden=!method;
 const russia=kind==='russia';
 toggle(city,russia&&!!method,['city',...(selected==='russian_post'?['postalCode']:[])]);
 toggle(courier,method==='courier',['street','house']);
 toggle(pvz,method==='pvz',['pickupPoint']);
 notice.textContent=!selected?'Выберите службу доставки.':!method?'Выберите ПВЗ или курьерскую доставку.':'Доступность услуги, стоимость и сроки подтвердит магазин.';
}
delivery.addEventListener('change',()=>{reset(carriers);reset(services);sync()});
carriers.forEach(item=>item.addEventListener('change',()=>{reset(services);sync()}));
services.forEach(item=>item.addEventListener('change',sync));
form.addEventListener('reset',()=>queueMicrotask(()=>{reset(carriers);reset(services);sync()}));
window.aromaDeliveryDetails=()=>{
 const kind=delivery.value;if(kind==='pickup')return{type:'pickup',carrier:'store',carrierLabel:'Самовывоз',service:'pickup',city:'Челябинск'};
 if(!['russia','courier'].includes(kind))return null;
 const f=new FormData(form),get=name=>String(f.get(name)||'').trim(),carrier=get('carrier'),service=get('service');
 return{type:kind,carrier,carrierLabel:names[carrier]||'',service,city:kind==='courier'?'Челябинск':get('city'),region:kind==='russia'?get('region'):'',postalCode:kind==='russia'?get('postalCode'):'',street:service==='courier'?get('street'):'',house:service==='courier'?get('house'):'',apartment:service==='courier'?get('apartment'):'',pickupPoint:service==='pvz'?get('pickupPoint'):''};
};
sync();
})();