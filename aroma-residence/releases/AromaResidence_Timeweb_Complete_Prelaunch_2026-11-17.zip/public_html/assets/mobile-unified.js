'use strict';(()=>{
 const panel=document.getElementById('mobile-navigation');
 if(!panel)return;
 const trigger=document.querySelector('.ar-unified-trigger');
 const closeButton=panel.querySelector('.mobile-nav-close');
 const badge=panel.querySelector('[data-ar-menu-count]');
 const recount=()=>{
  let cart=[];
  try{const saved=JSON.parse(localStorage.getItem('aroma-residence-cart-v1')||'[]');cart=Array.isArray(saved)?saved:[]}catch{}
  const count=cart.reduce((n,item)=>n+(Number.isInteger(item?.qty)&&item.qty>0&&item.qty<=30?item.qty:0),0);
  if(badge)badge.textContent=String(count);
  document.querySelectorAll('.ar-cart-link [data-ar-menu-count]').forEach(el=>el.textContent=String(count));
 };
 recount();
 window.addEventListener('storage',recount);
 window.addEventListener('aroma-cart-change',recount);
 if(!trigger)return;
 let prior=null;
 const open=()=>{
  const drawer=document.getElementById('drawer');
  if(drawer?.classList.contains('is-open'))document.getElementById('cart-close')?.click();
  prior=document.activeElement;
  panel.hidden=false;
  trigger.setAttribute('aria-expanded','true');
  document.body.classList.add('ar-mobile-menu-open');
  closeButton?.focus({preventScroll:true});
 };
 const close=()=>{
  if(panel.hidden)return;
  panel.hidden=true;
  trigger.setAttribute('aria-expanded','false');
  document.body.classList.remove('ar-mobile-menu-open');
  if(prior?.isConnected)prior.focus({preventScroll:true});
  prior=null;
 };
 trigger.addEventListener('click',()=>panel.hidden?open():close());
 closeButton?.addEventListener('click',close);
 panel.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{close()}));
 document.addEventListener('keydown',event=>{
  if(panel.hidden)return;
  if(event.key==='Escape'){event.preventDefault();close();return}
  if(event.key!=='Tab')return;
  const nodes=[...panel.querySelectorAll('a[href],button:not([disabled])')].filter(node=>node.getClientRects().length>0);
  if(!nodes.length)return;
  if(event.shiftKey&&document.activeElement===nodes[0]){event.preventDefault();nodes[nodes.length-1].focus()}
  else if(!event.shiftKey&&document.activeElement===nodes[nodes.length-1]){event.preventDefault();nodes[0].focus()}
 });
 window.addEventListener('pageshow',()=>{panel.hidden=true;trigger.setAttribute('aria-expanded','false');document.body.classList.remove('ar-mobile-menu-open');recount()});
})();
