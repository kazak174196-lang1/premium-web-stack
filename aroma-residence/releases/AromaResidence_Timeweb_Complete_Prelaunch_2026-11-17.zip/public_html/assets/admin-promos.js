'use strict';
(()=>{
 const panel=document.getElementById('promo-admin-panel'),dash=document.getElementById('dash'),form=document.getElementById('promo-admin-form'),list=document.getElementById('promo-admin-list'),status=document.getElementById('promo-admin-status');
 if(!panel||!dash||!form||!list||!status)return;
 const element=(tag,cls,text)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el};
 const send=async(method,query='',body)=>{
  const response=await fetch('/api/admin?action=promos'+query,{method,credentials:'same-origin',headers:{'content-type':'application/json','x-aroma-admin':'1'},body:body?JSON.stringify(body):undefined,cache:'no-store'});
  const data=await response.json().catch(()=>({error:'Некорректный ответ сервера.'}));
  if(!response.ok)throw Error(data.error||'Не удалось обработать промокод.');
  return data;
 };
 const date=x=>x?String(x):'';
 function edit(record){
  for(const key of ['code','description','percent','minAmount','maxUses','startsAt','expiresAt']){
   const el=form.elements.namedItem(key);if(el)el.value=record[key]??'';
  }
  form.elements.namedItem('active').checked=record.active===true;
  form.elements.namedItem('code').readOnly=true;
  form.scrollIntoView({behavior:'smooth',block:'start'});
 }
 function render(promos){
  list.replaceChildren();
  if(!promos.length){list.append(element('p','promo-empty','Промокодов пока нет. Создайте первый код для покупок обычных ароматов.'));return}
  for(const promo of promos){
   const card=element('article','promo-admin-card');
   const header=element('div','promo-admin-card-header');
   const code=element('strong','',promo.code);
   const badge=element('span',promo.active?'promo-state-active':'promo-state-off',promo.active?'Активен':'Выключен');
   header.append(code,badge);
   const info=element('p','', 'Скидка '+promo.percent+'% · минимальная сумма '+(promo.minAmount||0)+' ₽ · использовано '+(promo.used||0)+(promo.maxUses?' из '+promo.maxUses:''));
   const expires=element('p','promo-admin-small',promo.expiresAt?'До '+promo.expiresAt+' (Москва)':'Без даты окончания');
   const controls=element('div','promo-admin-card-actions');
   const button=element('button','','Редактировать');button.type='button';button.addEventListener('click',()=>edit(promo));
   const remove=element('button','promo-admin-remove','Удалить');remove.type='button';remove.addEventListener('click',async()=>{
    if(!window.confirm('Удалить промокод '+promo.code+'?'))return;
    remove.disabled=true;
    try{await send('DELETE','&code='+encodeURIComponent(promo.code));status.textContent='Промокод удалён.';await refresh()}
    catch(e){status.textContent=e.message;remove.disabled=false}
   });
   controls.append(button,remove);card.append(header,info,expires,controls);list.append(card);
  }
 }
 async function refresh(){
  if(dash.hidden){panel.hidden=true;return}
  panel.hidden=false;status.textContent='Загружаем промокоды…';
  try{const result=await send('GET');render(Array.isArray(result.promos)?result.promos:[]);status.textContent='Промокоды работают только для отдельных ароматов. На сеты дополнительных скидок нет.'}
  catch(e){status.textContent=e.message}
 }
 window.aromaRefreshPromos=refresh;
 form.addEventListener('submit',async event=>{
  event.preventDefault();
  if(dash.hidden||!form.reportValidity())return;
  const d=new FormData(form),code=String(d.get('code')||'').trim().toUpperCase();
  const record={code,description:String(d.get('description')||'').trim(),percent:Number(d.get('percent')),minAmount:Number(d.get('minAmount')||0),maxUses:Number(d.get('maxUses')||0),startsAt:String(d.get('startsAt')||''),expiresAt:String(d.get('expiresAt')||''),active:d.get('active')==='on'};
  const submit=form.querySelector('button[type="submit"]');submit.disabled=true;status.textContent='Сохраняем…';
  try{await send('PUT','',record);status.textContent='Промокод '+record.code+' сохранён.';form.reset();form.elements.namedItem('code').readOnly=false;await refresh()}
  catch(e){status.textContent=e.message}
  finally{submit.disabled=false}
 });
 document.getElementById('promo-admin-reset')?.addEventListener('click',()=>{form.reset();form.elements.namedItem('code').readOnly=false;status.textContent='Форма очищена.'});
 const observer=new MutationObserver(()=>{if(dash.hidden){panel.hidden=true}else refresh()});observer.observe(dash,{attributes:true,attributeFilter:['hidden']});queueMicrotask(()=>{if(!dash.hidden)refresh()});
})();
