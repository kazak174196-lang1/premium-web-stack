'use strict';(()=>{
const root=document.getElementById('set-builder');if(!root)return;
const grid=document.getElementById('set-grid'),state=document.getElementById('set-state'),total=document.getElementById('set-total'),add=document.getElementById('set-add');
let products=[],items=[],count=3;
const money=n=>new Intl.NumberFormat('ru-RU').format(n)+' ₽';
const sizes=p=>Object.entries(p?.prices||{}).filter(([ml,v])=>Number(ml)>0&&Number(v)>0).sort(([a],[b])=>Number(a)-Number(b));
const chosen=x=>products.find(p=>p.id===x?.id);
function render(){
grid.replaceChildren();let sum=0;let valid=true;
for(let i=0;i<count;i++){
 const row=items[i]||{id:'',ml:''},p=chosen(row),card=document.createElement('article');card.className='set-item';
 const index=document.createElement('span');index.className='set-index';index.textContent=String(i+1).padStart(2,'0');
 const image=document.createElement('div');image.className='set-image';
 if(p){const img=document.createElement('img');img.src=p.image&&p.image.startsWith('/assets/products/')?p.image:'/assets/products/'+encodeURIComponent(p.id)+'.webp';img.alt='Оригинальный флакон '+p.name;img.loading='lazy';img.decoding='async';img.width=280;img.height=280;img.addEventListener('error',()=>{image.textContent='ar.'},{once:true});image.append(img)}else image.textContent='ar.';
 const label=document.createElement('label');label.textContent='Выберите аромат';const perfume=document.createElement('select');perfume.add(new Option('Название аромата',''));for(const x of products)perfume.add(new Option(x.name,x.id));perfume.value=row.id;perfume.onchange=()=>{const match=products.find(x=>x.id===perfume.value);items[i]={id:perfume.value,ml:sizes(match)[0]?.[0]||''};render()};label.append(perfume);
 const second=document.createElement('label');second.textContent='Объём';const volume=document.createElement('select');
 if(!p){volume.disabled=true;volume.add(new Option('Сначала выберите аромат',''))}
 else for(const [ml,v] of sizes(p))volume.add(new Option(ml+' мл · '+money(Number(v)),ml));
 volume.value=row.ml;volume.onchange=()=>{items[i].ml=volume.value;render()};second.append(volume);
 const price=document.createElement('strong');price.textContent=p&&row.ml?money(Number(p.prices[row.ml])):'Выберите аромат';
 if(p&&row.ml)sum+=Number(p.prices[row.ml]);else valid=false;
 card.append(index,image,label,second,price);grid.append(card);
}
const discount=Math.round(sum*(count===3?5:10)/100);total.textContent=money(sum-discount);const original=document.getElementById('set-original');if(original)original.textContent=money(sum);const discounted=document.getElementById('set-discount');if(discounted)discounted.textContent='−'+money(discount);const ids=items.filter(x=>x?.id).map(x=>x.id);
if(new Set(ids).size!==ids.length){valid=false;state.textContent='Выберите разные ароматы для одной подборки.'}else state.textContent='';
add.disabled=!valid||ids.length!==count;
}
document.querySelectorAll('[data-set-count]').forEach(button=>button.onclick=()=>{count=Number(button.dataset.setCount);document.querySelectorAll('[data-set-count]').forEach(x=>x.setAttribute('aria-pressed',String(x===button)));const label=document.getElementById('set-discount-label');if(label)label.textContent=count===3?'Скидка на сет 5%':'Скидка на сет 10%';render()});
add.onclick=()=>{
 if(add.disabled)return;
 try{const key='aroma-residence-cart-v1',saved=JSON.parse(localStorage.getItem(key)||'[]');let cart=Array.isArray(saved)?saved:[];if(cart.length+count>80)throw Error('Корзина переполнена');
 const setId=crypto.randomUUID();for(const x of items.slice(0,count))cart.push({id:x.id,ml:String(x.ml),qty:1,setId})
 localStorage.setItem(key,JSON.stringify(cart));window.dispatchEvent(new Event('aroma-cart-change'));state.replaceChildren(document.createTextNode('Сет из '+count+' ароматов со скидкой '+(count===3?'5%':'10%')+' добавлен в корзину. '));const link=document.createElement('a');link.href='/cart/';link.textContent='Оформить заявку ↗';state.append(link);
 }catch(e){state.textContent=e.message||'Не удалось сохранить подборку'}
};
(async()=>{for(const url of ['/api/catalog','/assets/catalog-data.json']){try{const r=await fetch(url);if(!r.ok)continue;const d=await r.json(),list=Array.isArray(d)?d:d.products;if(Array.isArray(list)&&list.length){products=list.filter(p=>sizes(p).length).sort((a,b)=>a.name.localeCompare(b.name,'ru'));break}}catch{}}
if(products.length){state.textContent='';render()}else state.textContent='Не удалось загрузить каталог. Обновите страницу и повторите попытку.'})();
})();