'use strict';
(() => {
  const CONFIG = Object.freeze({
    catalogPath: '/catalog/',
    storageKey: 'aroma-residence-catalog-v2',
    previousStorageKey: 'aroma-residence-demo-v1',
    communityUrl: 'https://m.vk.ru/aromaresidence',
    volumes: Object.freeze([2, 3, 5, 10, 15]),
  });
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const icon = (name, extra = '') => `<svg class="icon ${extra}" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  const byId = (id) => state.products.find(item => item.id === id);
  const validSize = (size) => CONFIG.volumes.includes(Number(size)) ? Number(size) : 2;
  const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const plural = count => { const n = count % 100; const d = n % 10; return n > 10 && n < 20 ? 'ароматов' : d === 1 ? 'аромат' : d >= 2 && d <= 4 ? 'аромата' : 'ароматов'; };

  function readStorage() {
    let saved = {};
    try {
      saved = JSON.parse(localStorage.getItem(CONFIG.storageKey) || 'null') || {};
      // Migrate only favorites and volume preferences. Shopping carts are deliberately discarded.
      if (!Array.isArray(saved.favorites)) {
        const previous = JSON.parse(localStorage.getItem(CONFIG.previousStorageKey) || '{}');
        saved = {favorites: previous.favorites, size: previous.size};
        localStorage.removeItem(CONFIG.previousStorageKey);
      }
    } catch { saved = {}; }
    return {
      favorites: new Set(Array.isArray(saved.favorites) ? saved.favorites.filter(id => typeof id === 'string') : []),
      size: saved.size && typeof saved.size === 'object' && !Array.isArray(saved.size) ? saved.size : {},
    };
  }
  const persisted = readStorage();
  const state = {
    products: [], favorites: persisted.favorites, size: persisted.size,
    category:'Все', query:'', sort:'featured', onlyFavorites:false, onlyVerified:false,
    openedProduct:null, modalReturnPath:null, drawerOpen:false, focusReturn:null, toastTimer:0,
    pendingSearchFocus:null,
  };
  function save() {
    try { localStorage.setItem(CONFIG.storageKey, JSON.stringify({favorites:[...state.favorites], size:state.size})); }
    catch { /* Private browsing and disabled storage do not block catalog use. */ }
  }
  const volumeFor = id => validSize(state.size[id]);
  const rub = n => new Intl.NumberFormat('ru-RU').format(Number(n)) + ' ₽';
  const ROUTE_2GIS = 'https://2gis.ru/chelyabinsk/directions/points/|61.386977,55.167488';
  const ROUTE_YANDEX = 'https://yandex.ru/maps/56/chelyabinsk/?rtext=~55.167488%2C61.386977&rtt=auto';
  const routeButtons = '<a href="'+ROUTE_2GIS+'" class="button button-outline route-pill" target="_blank" rel="noopener noreferrer">Маршрут в 2ГИС ↗</a><a href="'+ROUTE_YANDEX+'" class="button button-outline route-pill" target="_blank" rel="noopener noreferrer">Яндекс Карты ↗</a>';
  function bottle(p) {
    if (p.image) return '<img class="product-real-photo" src="'+escapeHtml(p.image)+'" alt="Флакон '+escapeHtml(p.name)+'" loading="lazy" decoding="async" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span class="photo-unavailable" hidden>Фото пока недоступно</span>';
    return '<span class="photo-unavailable">Фотография отсутствует в прайсе</span>';
  }
  const availableVolumes = p => Object.keys(p.prices).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  const selectedVolume = p => {
    const options=availableVolumes(p);
    const selected=volumeFor(p.id);
    return options.includes(selected)?selected:options[0];
  };
  const verifiedBottleInfo={"amouage-guidance":{"sizes":[100],"url":"https://amouage.com/en-eu/products/100ml-guidance","verifiedAt":"2026-11-16","referenceName":"Amouage Guidance"},"initio-narcotic-delight":{"sizes":[50,90],"url":"https://initioparfums.com/products/narcotic-delight","verifiedAt":"2026-11-16","referenceName":"Initio Narcotic Delight"}};
function originalBottle(p){
const f=verifiedBottleInfo[p.id];
const opts=f?f.sizes.map(v=>'<option value="'+v+'">'+v+' мл</option>').join(''):'';
const text=f?'Подтверждённые объёмы производителя: '+f.sizes.join(' / ')+' мл. Цена и наличие в бутике уточняются.':'Объём, цену и наличие полного оригинального флакона уточните у магазина.';
return '<details class="ar-full-bottle ar-full-card"><summary>Целый флакон <span>по запросу</span></summary><div class="ar-full-bottle-content"><p>'+text+'</p>'+(f?'<label>Объём<select aria-label="Объём оригинального флакона">'+opts+'</select></label>':'')+'<div class="ar-full-bottle-links"><a class="ar-bottle-request" href="https://m.vk.ru/aromaresidence" data-bottle-name="'+escapeHtml(p.name)+'" target="_blank" rel="noopener noreferrer">Уточнить цену ↗</a>'+(f?'<a class="ar-bottle-official" href="'+f.url+'" target="_blank" rel="noopener noreferrer">Сайт бренда ↗</a>':'')+'</div></div></details>';
}function card(p) {
    const favorite=state.favorites.has(p.id);
    const volumes=availableVolumes(p);
    const selected=selectedVolume(p);
    return '<article class="product-card" data-id="'+escapeHtml(p.id)+'">'+
      '<a class="product-card-image product-photo-wrap" href="/catalog/'+escapeHtml(p.id)+'/" aria-label="Открыть аромат '+escapeHtml(p.name)+'">'+
      bottle(p)+'<span class="product-explore">'+icon('arrow')+'</span></a>'+
      '<button class="favorite-card '+(favorite?'active':'')+'" type="button" data-favorite="'+escapeHtml(p.id)+'" aria-pressed="'+favorite+'" aria-label="'+(favorite?'Убрать из избранного':'Сохранить в избранное')+': '+escapeHtml(p.name)+'">'+icon('heart')+'</button>'+
      '<div class="product-card-info"><div class="product-card-info-top"><span>'+escapeHtml(p.brand)+'</span><span>ПАРФЮМЕРИЯ НА РАСПИВ</span></div>'+
      '<a class="product-name-button" href="/catalog/'+escapeHtml(p.id)+'/">'+escapeHtml(p.title)+'</a>'+
      '<p class="product-subtitle">'+escapeHtml(p.brand)+'</p>'+
      '<div class="card-volume-label" id="size-label-'+escapeHtml(p.id)+'">Объём флакона</div>'+
      '<div class="card-volume-options" role="group" aria-labelledby="size-label-'+escapeHtml(p.id)+'">'+
      volumes.map(ml=>'<button class="card-volume-option '+(ml===selected?'active':'')+'" type="button" data-card-size="'+ml+'" data-product-id="'+escapeHtml(p.id)+'" aria-pressed="'+(ml===selected)+'" aria-label="'+ml+' мл, '+escapeHtml(p.name)+'">'+ml+' мл</button>').join('')+'</div>'+
      '<div class="card-price" aria-live="polite" aria-atomic="true"><strong data-card-price>'+rub(p.prices[String(selected)])+'</strong><span data-card-unit>/ '+selected+' мл</span></div>'+
      (p.notes?'<div class="card-verification">Ноты по данным производителя</div>':'')+
      '<button type="button" class="ar-add-card" data-cart-add="'+escapeHtml(p.id)+'" aria-label="Добавить '+escapeHtml(p.name)+' в корзину">В корзину <span aria-hidden="true">+</span></button>'+'<p class="ar-original-assurance">Только оригинальная парфюмерия</p>'+originalBottle(p)+ '<a class="product-discover" href="/catalog/'+escapeHtml(p.id)+'/" ><span>Подробнее об аромате</span>'+icon('arrow')+'</a></div></article>';
  }
  function setVolume(id, selected, cardElement=null) {
    const product=byId(id);
    if (!product || !availableVolumes(product).includes(selected))return false;
    state.size[id]=selected;
    save();
    const container=cardElement||$('#product-grid .product-card[data-id="'+id+'"]');
    if(container){
      $$('[data-card-size]',container).forEach(chip=>{
        const active=Number(chip.dataset.cardSize)===selected;
        chip.classList.toggle('active',active);
        chip.setAttribute('aria-pressed',String(active));
      });
      const price=$('[data-card-price]',container),unit=$('[data-card-unit]',container);
      if(price)price.textContent=rub(product.prices[String(selected)]);
      if(unit)unit.textContent='/ '+selected+' мл';
    }
    const seoPage=$('[data-product-page]');
    if(seoPage && seoPage.dataset.productPage===id){
      $$('[data-page-size]',seoPage).forEach(button=>{
        const active=Number(button.dataset.pageSize)===selected;
        button.classList.toggle('active',active);
        button.setAttribute('aria-pressed',String(active));
      });
      const amount=$('[data-page-amount]',seoPage),price=$('[data-page-price]',seoPage);
      if(amount)amount.textContent=selected+' мл';
      if(price)price.textContent=rub(product.prices[String(selected)]);
    }
    if(state.openedProduct===id){
      $$('.modal-size-row [data-modal-size]').forEach(chip=>{
        const active=Number(chip.dataset.modalSize)===selected;
        chip.classList.toggle('active',active);
        chip.setAttribute('aria-pressed',String(active));
      });
      const label=$('#modal-price-label'),value=$('#modal-price-value');
      if(label)label.textContent='Цена за '+selected+' мл';
      if(value)value.textContent=rub(product.prices[String(selected)]);
    }
    return true;
  }
  function matchingProducts() {
    let items = state.products.filter(p => (!state.onlyFavorites || state.favorites.has(p.id)) && (!state.onlyVerified || (p.notes && p.officialUrl)));
    if (state.category !== 'Все') items = items.filter(p => p.brand === state.category);
    const query = state.query.trim().toLocaleLowerCase('ru');
    if (query) items=items.filter(p => searchCorpus(p).includes(query));
    if (state.sort === 'name') items.sort((a,b)=>a.name.localeCompare(b.name,'ru'));
    if (state.sort === 'name-desc') items.sort((a,b)=>b.name.localeCompare(a.name,'ru')); const priceMin = p => Math.min(...Object.values(p.prices).map(Number)); if (state.sort === 'price-asc') items.sort((a,b)=>priceMin(a)-priceMin(b)); if (state.sort === 'price-desc') items.sort((a,b)=>priceMin(b)-priceMin(a));
    return items;
  }
  function renderGrid() {
    const items = matchingProducts();
    $('#product-grid').innerHTML = items.map(card).join('');
    $('#catalog-empty').hidden = items.length > 0;
    $('#result-count').textContent = `${items.length} ${plural(items.length)}`;
    $('#reset-filters').hidden = state.category === 'Все' && !state.query && !state.onlyFavorites && !state.onlyVerified;
    $('#catalog-search').value = state.query;
    $('#sort-select').value = state.sort; $('#brand-filter').value=state.category; const verifiedButton=$('#verified-filter'); verifiedButton.classList.toggle('selected',state.onlyVerified); verifiedButton.setAttribute('aria-pressed',String(state.onlyVerified));
    $$('#filter-buttons .filter-pill[data-category]').forEach(button => {
      const selected = button.dataset.category === state.category;
      button.classList.toggle('selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    updateCounts();
  }
  function updateCounts() {
    $$('.favorites-count').forEach(node => {
      node.hidden = state.favorites.size === 0;
      node.textContent = state.favorites.size > 99 ? '99+' : String(state.favorites.size);
    });
  }
  function resetFilters() {
    state.category = 'Все';state.query = '';state.sort = 'featured';state.onlyFavorites = false;state.onlyVerified=false;renderGrid();
  }
  function selectCategory(category) { state.category = category; state.onlyFavorites = false; renderGrid(); }
  function toggleFavorite(id) {
    const item = byId(id);
    if (!item) return;
    const added = !state.favorites.has(id);
    if (added) state.favorites.add(id); else state.favorites.delete(id);
    save();renderGrid();
    if (state.drawerOpen) renderDrawer();
    if (state.openedProduct === id) renderModal();
    toast(added ? 'Аромат сохранён в избранном' : 'Аромат удалён из избранного');
  }
  function toast(message) {
    const el = $('#toast');
    clearTimeout(state.toastTimer);
    el.hidden = false;
    el.innerHTML = `${icon('check')}<span class="toast-message">${escapeHtml(message)}</span>`;
    state.toastTimer = window.setTimeout(() => {el.hidden = true;}, 3500);
  }
  const showLock = () => document.body.classList.toggle('locked', state.drawerOpen || !!state.openedProduct || !$('#mobile-navigation').hidden);
  function rememberFocus() { state.focusReturn = document.activeElement; }
  function restoreFocus() { if (state.focusReturn?.isConnected) state.focusReturn.focus(); state.focusReturn = null; }
  function showBackdrop() { $('#backdrop').hidden = !state.drawerOpen;showLock(); }
  function closeDrawer(restore = true) {
    if (!state.drawerOpen) return;
    state.drawerOpen = false;$('#drawer').hidden = true;showBackdrop();
    if (restore) restoreFocus();
  }
  function openDrawer() {
    if (state.openedProduct) closeModal(false);
    rememberFocus();state.drawerOpen = true;
    $('#drawer').hidden = false;showBackdrop();renderDrawer();$('.close-drawer').focus();
  }
  function renderDrawer() {
    const content = $('#drawer-content');const footer = $('#drawer-footer');
    const savedItems = state.products.filter(p => state.favorites.has(p.id));
    $('#drawer-heading').textContent = 'Избранное';$('#drawer-kicker').textContent = 'ВАША КОЛЛЕКЦИЯ';
    if (!savedItems.length) {
      content.innerHTML = `<div class="drawer-empty">${icon('heart')}<h3>Пока ничего не сохранено</h3><p>Нажмите на сердечко рядом с ароматом, чтобы легко вернуться к нему.</p><button class="button button-outline drawer-go-catalog" type="button">Перейти в каталог ${icon('arrow')}</button></div>`;
      footer.innerHTML = '';
      return;
    }
    content.innerHTML = savedItems.map(p => `<div class="drawer-row" data-drawer-id="${escapeHtml(p.id)}">
      <button class="drawer-mini" data-open-saved="${escapeHtml(p.id)}" aria-label="Открыть ${escapeHtml(p.name)}">${bottle(p)}</button>
      <div class="drawer-item"><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.brand)}</p><button type="button" class="drawer-view" data-open-saved="${escapeHtml(p.id)}">Подробнее ${icon('arrow')}</button></div>
      <button class="drawer-remove" type="button" data-unfavorite="${escapeHtml(p.id)}" aria-label="Убрать ${escapeHtml(p.name)} из избранного">${icon('close')}</button></div>`).join('');
    footer.innerHTML = `<button class="button button-outline" id="favorites-show" type="button">Показать избранные ароматы ${icon('arrow')}</button><a class="drawer-community" href="${CONFIG.communityUrl}" rel="noopener noreferrer" target="_blank">Нужна помощь с выбором? Напишите нам ${icon('arrow')}</a>`;
  }
  function modalMarkup(p) {
    const options = availableVolumes(p);
    const selected = selectedVolume(p);
    const favorite = state.favorites.has(p.id);
    const verified = p.notes && Object.keys(p.notes).length > 0;
    const notes = verified
      ? '<div class="notes-label">Ноты аромата · по данным производителя</div><div class="notes-list">' +
        (p.notes.all
          ? '<div><span>Ключевые ноты</span>'+escapeHtml(p.notes.all)+'</div>'
          : [['top','Верхние'],['heart','Сердце'],['base','База']].map(([key,label])=>
              p.notes[key] ? '<div><span>'+label+'</span>'+escapeHtml(p.notes[key])+'</div>' : '').join(''))+
        '</div><a class="official-source" href="'+escapeHtml(p.officialUrl)+'" target="_blank" rel="noopener noreferrer">Первоисточник: сайт производителя ↗</a>'
      : (p.officialUrl
        ? '<p class="unverified-notes">Производитель не указал точную пирамиду нот. Описание составлено по его официальной публикации.</p><a class="official-source" href="'+escapeHtml(p.officialUrl)+'" target="_blank" rel="noopener noreferrer">Описание: официальный сайт производителя ↗</a>'
        : (p.editorialSourceUrl ? '<p class="unverified-notes">Описание основано на материалах независимого парфюмерного магазина.</p><a class="official-source" href="'+escapeHtml(p.editorialSourceUrl)+'" target="_blank" rel="nofollow noopener noreferrer">Источник описания ↗</a>' : '<p class="unverified-notes">Уточните композицию у магазина.</p>'));
    return '<div class="modal-layout"><div class="modal-photo real-modal-photo">'+bottle(p)+
      '<span class="modal-visual-caption">AROMA RESIDENCE / PRICE COLLECTION</span></div>'+
      '<div class="modal-info"><p class="section-kicker">'+escapeHtml(p.brand)+' · ПАРФЮМЕРИЯ</p>'+
      '<h2 id="modal-title">'+escapeHtml(p.title)+'</h2><div class="modal-sub">'+escapeHtml(p.name)+'</div>'+
      '<section class="modal-buy-panel" aria-label="Выбор объёма и цена">'+
        '<div class="modal-select-label">Выберите объём</div>'+
        '<div class="modal-size-row" role="group" aria-label="Объём аромата">'+
          options.map(ml=>'<button type="button" class="size-chip '+(ml===selected?'active':'')+
            '" data-modal-size="'+ml+'" aria-pressed="'+(ml===selected)+'" aria-label="'+ml+' мл">'+ml+' мл</button>').join('')+
        '</div>'+
        '<div class="modal-price" aria-live="polite" aria-atomic="true"><span id="modal-price-label">Цена за '+selected+' мл</span>'+
          '<strong id="modal-price-value">'+rub(p.prices[String(selected)])+'</strong></div>'+
        '<p class="modal-volume-note">Цена указана за выбранный объём. Наличие уточняйте перед посещением.</p>'+'<button type="button" class="ar-add-modal" data-cart-add="'+escapeHtml(p.id)+'">Добавить в корзину <span aria-hidden="true">+</span></button>'+
      '</section>'+
      '<div class="modal-fragrance-details"><p class="modal-desc">'+escapeHtml(p.description||
        'Откройте характер аромата и подберите удобный объём.')+'</p>'+
        notes+'</div>'+
      '<div class="modal-routes"><p class="section-kicker">КАК ДОБРАТЬСЯ</p>'+
        '<p>Челябинск, ул. Труда, 163/1, павильон 5</p><div class="route-actions">'+routeButtons+'</div></div>'+
      '<button class="modal-favorite '+(favorite?'is-saved':'')+'" type="button" data-favorite="'+escapeHtml(p.id)+'">'+
        icon('heart')+(favorite?'Убрать из избранного':'Сохранить в избранное')+'</button></div></div>';
  }
  function renderModal() {
    const p = byId(state.openedProduct);
    if (!p) return;
    const shell = $('.modal-shell');
    const scrollPosition = shell.scrollTop;
    $('#modal-content').innerHTML = modalMarkup(p);
    shell.scrollTop = scrollPosition;
  }
  function openModal(id, push = true) {
    if (!byId(id)) return;
    if (state.drawerOpen) closeDrawer(false);
    rememberFocus();state.modalReturnPath = location.pathname + location.search;state.openedProduct = id;renderModal();$('#product-modal').hidden = false;showLock();$('.modal-shell').scrollTop = 0;$('.modal-close').focus();
    if (push) { const path = CONFIG.catalogPath + id + '/';if (location.pathname !== path) history.pushState({product:id},'',path); }
  }
  function closeModal(push = true) {
    if (!state.openedProduct) return;
    state.openedProduct = null;$('#product-modal').hidden = true;showLock();
    if (push && location.pathname.startsWith(CONFIG.catalogPath) && location.pathname !== CONFIG.catalogPath) history.pushState({},'',state.modalReturnPath && document.querySelector('[data-product-page]') ? state.modalReturnPath : CONFIG.catalogPath);
    state.modalReturnPath=null;
    restoreFocus();
  }
  function openSaved(id) { closeDrawer(false);openModal(id); }
  const searchCorpus = p => [p.name,p.title,p.brand,p.description||'',...Object.values(p.notes||{})].join(' ').toLocaleLowerCase('ru');
  function closeMobileNavigation(restore=false) {
    const panel=$('#mobile-navigation');
    if(panel.hidden)return;
    panel.hidden=true;
    $('.mobile-menu-trigger').setAttribute('aria-expanded','false');
    showLock();
    if(restore)$('.mobile-menu-trigger').focus();
  }
  function positionSearchPanel() {
    const top=Math.max(0,Math.ceil($('#site-header').getBoundingClientRect().bottom));
    $('#search-overlay').style.setProperty('--search-top',top+'px');
  }
  function renderSearchSuggestions() {
    const query=$('#overlay-search-input').value.trim().toLocaleLowerCase('ru');
    const matched=query?state.products.filter(p=>searchCorpus(p).includes(query)):state.products.slice(0,6);
    const resultCount=matched.length;
    $('#search-results-label').textContent=query?(resultCount+' '+plural(resultCount)+' найдено'):'Начните с ароматов коллекции';
    const suggestions=$('#search-suggestions');
    suggestions.innerHTML=matched.length
      ? matched.slice(0,6).map(p=>{
        const ml=selectedVolume(p);
        return '<button type="button" class="search-result" data-search-open="'+escapeHtml(p.id)+'" aria-label="Открыть '+escapeHtml(p.name)+'">'+
          '<span class="search-result-photo">'+(p.image?'<img src="'+escapeHtml(p.image)+'" alt="" loading="lazy" decoding="async">':'<span>AR</span>')+'</span>'+
          '<span class="search-result-main"><span class="search-result-brand">'+escapeHtml(p.brand)+'</span>'+
          '<strong>'+escapeHtml(p.title)+'</strong><span class="search-result-price">'+ml+' мл · '+rub(p.prices[String(ml)])+'</span></span>'+
          '<span class="search-result-arrow">'+icon('arrow')+'</span></button>';
      }).join('')
      : '<div class="search-no-results">Не нашли подходящий аромат. Попробуйте другое название, бренд или ноту.</div>';
    const button=$('#search-all-results');
    button.hidden=Boolean(query)&&resultCount===0;
    button.querySelector('span').textContent=query?'Показать все '+resultCount+' '+plural(resultCount):'Открыть весь каталог';
  }
  function closeSearch(returnFocus=false) {
    const panel=$('#search-overlay');
    if(panel.hidden)return;
    panel.hidden=true;
    $('.search-trigger').setAttribute('aria-expanded','false');
    if(returnFocus)$('.search-trigger').focus();
  }
  function openSearch() {
    if(state.drawerOpen)closeDrawer(false);
    if(state.openedProduct)closeModal(false);
    closeMobileNavigation();
    positionSearchPanel();
    const panel=$('#search-overlay');
    panel.hidden=false;
    $('.search-trigger').setAttribute('aria-expanded','true');
    $('#overlay-search-input').value=state.query;
    renderSearchSuggestions();
    $('#overlay-search-input').focus();
  }
  function applySearch() {
    state.query=$('#overlay-search-input').value.trim();
    state.category='Все';
    state.onlyFavorites=false;
    state.onlyVerified=false;
    renderGrid();
    closeSearch();
    scrollCatalog();
    $('#catalog-search').focus({preventScroll:true});
  }
  function scrollCatalog() {$('#catalog').scrollIntoView({behavior:reducedMotion()?'auto':'smooth'});}
  function normalizeState() {
    const validIds = new Set(state.products.map(p => p.id));
    state.favorites = new Set([...state.favorites].filter(id => validIds.has(id)));
    state.size = Object.fromEntries(Object.entries(state.size).filter(([id]) => validIds.has(id)).map(([id,volume]) => [id,validSize(volume)]));
    save();
  }
  async function init() {
    try {
      const response = await fetch('/products.json',{cache:'no-cache'});
      if (!response.ok) throw new Error('Fetch failed');
      const data = await response.json();
      if (!Array.isArray(data)) throw new Error('Invalid catalog');
      state.products = data.filter(p => p && typeof p.id==='string' && /^[a-z0-9-]+$/.test(p.id) && typeof p.name==='string' && typeof p.brand==='string' && typeof p.group==='string' && p.prices && typeof p.prices==='object' && Object.keys(p.prices).length>0);
      if (!state.products.length) throw new Error('Empty catalog');
      normalizeState();
      if(new URLSearchParams(location.search).get('favorites')==='1')state.onlyFavorites=true;
      const brands=[...new Set(state.products.map(p=>p.brand))].sort((a,b)=>a.localeCompare(b,'ru'));
      const popular=brands.map(name=>({name,count:state.products.filter(p=>p.brand===name).length}))
        .sort((a,b)=>b.count-a.count || a.name.localeCompare(b.name,'ru')).slice(0,8);
      $('#filter-buttons').innerHTML='<button class="filter-pill selected" data-category="Все" aria-pressed="true">Все ароматы</button>'+
        popular.map(item=>'<button class="filter-pill" data-category="'+escapeHtml(item.name)+'" aria-pressed="false">'+escapeHtml(item.name)+'</button>').join('')+
        '<button id="verified-filter" class="filter-pill verified-pill" type="button" aria-pressed="false">✓ Ноты производителей</button>';
      $('#brand-filter').innerHTML='<option value="Все">Все бренды ('+brands.length+')</option>'+
        brands.map(name=>'<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>').join('');
      $('#verified-count').textContent=String(state.products.filter(p=>p.notes && p.officialUrl).length);
      renderGrid();
      const requested = location.pathname.match(/^\/catalog\/([a-z0-9-]+)\/?$/);
      const staticProduct=$('[data-product-page]');
      if(staticProduct && byId(staticProduct.dataset.productPage)){
        const requestedVolume=Number(new URLSearchParams(location.search).get('ml'));
        const product=byId(staticProduct.dataset.productPage);
        const defaultVolume=selectedVolume(product);
        const selected=availableVolumes(product).includes(requestedVolume)?requestedVolume:defaultVolume;
        setVolume(product.id,selected);
      }
      if (requested && byId(requested[1]) && !staticProduct) openModal(requested[1], false);
    } catch {
      $('#product-grid').innerHTML = `<div class="load-error" role="alert"><h3>Не удалось загрузить каталог</h3><p>Проверьте подключение к интернету и попробуйте ещё раз. Если проблема повторяется, напишите нам во ВКонтакте.</p><button type="button" class="button button-outline" id="catalog-retry">Повторить загрузку</button></div>`;
      $('#catalog-retry').addEventListener('click', init);
      $('#result-count').textContent = 'Каталог недоступен';
    }
  }
  document.addEventListener('click', event => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const searchOpen=target.closest('[data-search-open]');
    if(searchOpen){closeSearch(true);openModal(searchOpen.dataset.searchOpen);return;}
    const mobileSearch=target.closest('[data-open-search]');
    if(mobileSearch){closeMobileNavigation();openSearch();return;}
    const mobileFavorite=target.closest('[data-show-favorites]');
    if(mobileFavorite){closeMobileNavigation();openDrawer();return;}
    const brandNavigation=target.closest('[data-nav-brands]');
    if(brandNavigation){
      closeSearch();
      closeMobileNavigation();
      window.setTimeout(()=>{
        const brand=$('#brand-filter');
        if(brand){brand.focus({preventScroll:true});}
      },reducedMotion()?0:420);
    }
    const category = target.closest('[data-category]');
    if (category) {selectCategory(category.dataset.category);return;}
    const favorite = target.closest('[data-favorite]');
    if (favorite) {toggleFavorite(favorite.dataset.favorite);return;}
    const open = target.closest('[data-open]');
    if (open) {openModal(open.dataset.open);return;}
    const saved = target.closest('[data-open-saved]');
    if (saved) {openSaved(saved.dataset.openSaved);return;}
    const unfavorite = target.closest('[data-unfavorite]');
    if (unfavorite) {toggleFavorite(unfavorite.dataset.unfavorite);return;}
    const goToCatalog = target.closest('.drawer-go-catalog');
    if (goToCatalog) {closeDrawer();scrollCatalog();return;}
    const showFavorites = target.closest('#favorites-show');
    if (showFavorites) {closeDrawer();state.onlyFavorites=true;state.category='Все';state.query='';renderGrid();scrollCatalog();return;}
    const pageSize=target.closest('[data-page-size]');
    if(pageSize){
      const seoPage=pageSize.closest('[data-product-page]');
      if(seoPage)setVolume(seoPage.dataset.productPage,Number(pageSize.dataset.pageSize));
      return;
    }
    const cardSize=target.closest('[data-card-size]');
    if(cardSize){
      const id=cardSize.dataset.productId,selected=Number(cardSize.dataset.cardSize);
      setVolume(id,selected,cardSize.closest('.product-card'));
      return;
    }
    const modalSize=target.closest('[data-modal-size]');
    if(modalSize && state.openedProduct){
      setVolume(state.openedProduct,Number(modalSize.dataset.modalSize));
      return;
    }
    const discover = target.closest('[data-discover]');
    if (discover) {state.category=discover.dataset.discover;state.query='';state.onlyFavorites=false;renderGrid();scrollCatalog();}
  });
  $('#catalog-search').addEventListener('input', event => {state.query=event.target.value;renderGrid();});
  $('#sort-select').addEventListener('change', event => {state.sort=event.target.value;renderGrid();});
  $('#brand-filter').addEventListener('change', event => {selectCategory(event.target.value);});
  $('#filter-buttons').addEventListener('click',event => {
    const filter=event.target.closest('#verified-filter');
    if(filter){state.onlyVerified=!state.onlyVerified;renderGrid();}
  });
  $('#reset-filters').addEventListener('click',resetFilters);
  $('#empty-reset').addEventListener('click',resetFilters);
  $$('.favorites-trigger').forEach(button => button.addEventListener('click',openDrawer));
  $('.close-drawer').addEventListener('click',closeDrawer);
  $('#backdrop').addEventListener('click',closeDrawer);
  $('.modal-close').addEventListener('click', () => closeModal());
  $('#product-modal').addEventListener('click', event => {if (event.target === $('#product-modal')) closeModal();});
  $('.search-trigger').addEventListener('click',()=>$('#search-overlay').hidden?openSearch():closeSearch(true));
  $('.search-close').addEventListener('click',()=>closeSearch(true));
  $('#overlay-search-input').addEventListener('input',renderSearchSuggestions);
  $('#header-search-form').addEventListener('submit',event=>{event.preventDefault();applySearch();});
  $('#search-all-results').addEventListener('click',applySearch);
  $('.mobile-menu-trigger').addEventListener('click',()=>{
    closeSearch();
    $('#mobile-navigation').hidden=false;
    $('.mobile-menu-trigger').setAttribute('aria-expanded','true');
    showLock();
    $('.mobile-nav-close').focus();
  });
  $('.mobile-nav-close').addEventListener('click',()=>closeMobileNavigation(true));
  $$('#mobile-navigation a').forEach(link=>link.addEventListener('click',()=>closeMobileNavigation()));
  document.addEventListener('pointerdown',event=>{
    if($('#search-overlay').hidden)return;
    if(event.target.closest('#search-overlay')||event.target.closest('.search-trigger'))return;
    closeSearch();
  });
  window.addEventListener('resize',()=>{if(!$('#search-overlay').hidden)positionSearchPanel();},{passive:true});
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (state.openedProduct) closeModal();
      else if (state.drawerOpen) closeDrawer();
      else if (!$('#mobile-navigation').hidden) closeMobileNavigation(true);
      else closeSearch(true);
      return;
    }
    if (event.key !== 'Tab') return;
    const activePanel = state.openedProduct ? $('#product-modal') : state.drawerOpen ? $('#drawer') : !$('#mobile-navigation').hidden ? $('#mobile-navigation') : null;
    if (!activePanel) return;
    const nodes = $$('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled])', activePanel).filter(node => node.getClientRects().length);
    if (!nodes.length) return;
    if (event.shiftKey && document.activeElement === nodes[0]) {event.preventDefault();nodes.at(-1).focus();}
    else if (!event.shiftKey && document.activeElement === nodes.at(-1)) {event.preventDefault();nodes[0].focus();}
  });
  window.addEventListener('popstate',()=>{
    const requested = location.pathname.match(/^\/catalog\/([a-z0-9-]+)\/?$/);
    const staticProduct=$('[data-product-page]');
    if(staticProduct && requested && requested[1]===staticProduct.dataset.productPage){
      if(state.openedProduct)closeModal(false);
    } else if(requested && byId(requested[1]))openModal(requested[1],false);
    else if(state.openedProduct)closeModal(false);
  });
  const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}});},{rootMargin:'0px 0px -45px 0px',threshold:.06}) : null;
  $$('[data-reveal]').forEach(node=>observer?observer.observe(node):node.classList.add('visible'));
  window.addEventListener('scroll',()=>{$('#site-header').classList.toggle('scrolled',scrollY>18);if(!$('#search-overlay').hidden)positionSearchPanel();},{passive:true});
  init();
})();
