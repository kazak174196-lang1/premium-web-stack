'use strict';
(() => {
  const page=document.querySelector('[data-product-page]');
  if(!page)return;
  const productId=page.dataset.productPage;
  const storageKey='aroma-residence-catalog-v2';
  const volumeButtons=[...page.querySelectorAll('[data-page-size]')];
  const priceElement=page.querySelector('[data-page-price]');
  const amountElement=page.querySelector('[data-page-amount]');
  const favoriteButton=page.querySelector('[data-save-favorite]');
  const favoriteLabel=page.querySelector('[data-save-label]');
  function readSaved(){
    try{
      const stored=JSON.parse(localStorage.getItem(storageKey)||'{}');
      return {
        favorites:Array.isArray(stored.favorites)?stored.favorites.filter(v=>typeof v==='string'):[],
        size:stored.size&&typeof stored.size==='object'&&!Array.isArray(stored.size)?stored.size:{}
      };
    }catch{return {favorites:[],size:{}};}
  }
  let saved=readSaved();
  const format=new Intl.NumberFormat('ru-RU');
  const supported=volumeButtons.map(b=>Number(b.dataset.pageSize));
  function save(){
    try{localStorage.setItem(storageKey,JSON.stringify(saved));}catch{/* Optional preferences must not interrupt the website. */}
  }
  function selectVolume(volume){
    if(!supported.includes(volume))return;
    const button=volumeButtons.find(b=>Number(b.dataset.pageSize)===volume);
    if(!button)return;
    const price=Number(button.dataset.priceValue);
    if(!Number.isFinite(price)||price<0)return;
    volumeButtons.forEach(b=>{
      const chosen=Number(b.dataset.pageSize)===volume;
      b.classList.toggle('active',chosen);
      b.setAttribute('aria-pressed',String(chosen));
    });
    if(amountElement)amountElement.textContent=volume+' мл';
    if(priceElement)priceElement.textContent=format.format(price)+' ₽';
    saved.size[productId]=volume;
    save();
  }
  function refreshFavorite(){
    if(!favoriteButton)return;
    const isFavorite=saved.favorites.includes(productId);
    favoriteButton.setAttribute('aria-pressed',String(isFavorite));
    favoriteButton.classList.toggle('is-saved',isFavorite);
    favoriteButton.setAttribute('aria-label',isFavorite?'В избранном':'Сохранить аромат');
    if(favoriteLabel)favoriteLabel.textContent=isFavorite?'В избранном':'Сохранить аромат';
  }
  volumeButtons.forEach(button=>button.addEventListener('click',()=>selectVolume(Number(button.dataset.pageSize))));
  const requested=new URLSearchParams(location.search).get('ml');
  const persisted=Number(saved.size[productId]);
  const nextVolume=requested!==null&&supported.includes(Number(requested))?Number(requested):supported.includes(persisted)?persisted:supported[0];
  selectVolume(nextVolume);
  if(favoriteButton){
    favoriteButton.addEventListener('click',()=>{
      if(saved.favorites.includes(productId))saved.favorites=saved.favorites.filter(id=>id!==productId);
      else saved.favorites.push(productId);
      save();refreshFavorite();
    });
    refreshFavorite();
  }
  document.addEventListener('keydown',event=>{
    if(event.key!=='Escape')return;
    document.querySelectorAll('details.seo-mobile-menu[open]').forEach(el=>el.open=false);
  });
})();

